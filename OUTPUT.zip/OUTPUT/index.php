<!DOCTYPE HTML>
    <html lang = "en">

        <HEAD>
            <?php include 'href.html';?>
        </HEAD>

        <body>       
            <div class='header' >
                <?php include 'header.html';?>
            </div>

            <?php include 'home.html';?>
                
            <div class='footer' >
                <?php include 'footer.html';?>
            </div>

        </body>

    </html>