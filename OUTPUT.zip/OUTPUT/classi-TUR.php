<HTML>

<HEAD>
    <?php include 'href.html';?>
</HEAD>

<BODY>
    <div class='header'>
        <?php include 'header.html';?>
    </div>

    <div align="center">
        <div class="responsive" style="vertical-align: top;">
            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 class="tabel launch">

                <TR VALIGN=TOP>

                    <Th ALIGN=TOP class='mathema'>
                        <b>CLASSI TERZE TUR</b>
                    </Th>
                </tr>
                <tr>
                    <td><A HREF="Classi/3F TUR.php" class='mathema'>3F TUR</A><BR></td>
                </tr>
                <tr>
                    <td><A HREF="Classi/3G TUR.php" class='mathema'>3G TUR</A><BR></td>
                </tr>
                <!--                 <tr>
                    <td class='mathema'>
                      <p> &nbsp</p>
                    </td>
                </tr>
                <tr>
                    <td class='mathema'>
                    </td>
                </tr> -->
            </TABLE>
        </div>
        <div class="responsive" style="vertical-align: top;">
            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 class="tabel launch">

                <TR VALIGN=TOP>

                    <Th ALIGN=TOP class='mathema'>
                        <b>CLASSI QUARTE TUR</b>
                    </Th>
                </tr>

                <tr>
                    <td><A HREF="Classi/4D TUR.php" class='mathema'>4D TUR</A><BR></td>
                </tr>
                <tr>
                    <td><A HREF="Classi/4E TUR.php" class='mathema'>4E TUR</A><BR></td>
                </tr>
                <!--                 <tr>
                    <td class='mathema'>
                      <p> &nbsp</p>
                    </td>
                </tr>
                <tr>
                    <td class='mathema'>
                    </td>
                </tr> -->
            </TABLE>
        </div>
        <div class="responsive" style="vertical-align: top;">
            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 class="tabel launch">

                <TR VALIGN=TOP>

                    <Th ALIGN=TOP class='mathema'>
                        <b>CLASSI QUINTE TUR</b>
                    </Th>
                </tr>
                <tr>
                    <td><A HREF="Classi/5E TUR.php" class='mathema'>5E TUR</A><BR></td>
                </tr>
                <tr>
                    <td><A HREF="Classi/5F TUR.php" class='mathema'>5F TUR</A><BR></td>
                </tr>
                <tr>
                    <td><A HREF="Classi/5G TUR.php" class='mathema'>5G TUR</A><BR></td>
                </tr>
                <!--                 <tr>
                    <td>
                    </td>
                </tr> -->
            </TABLE>
        </div>
    </div>
    <div class='footer'>
        <?php include 'footer.html';?>

    </div>

</BODY>

</HTML>