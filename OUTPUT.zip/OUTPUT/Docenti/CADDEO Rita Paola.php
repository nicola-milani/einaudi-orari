<html>
    <head>
        <?php include '../href.html';?>
    </head>
    <body>
        <?php include '../header.html';?>
        <div align="center">
<p class='mathema'>
ORARIO DOCENTE CADDEO Rita Paola</p>
</div>
    <div align="center">


<table BORDER=2 WIDTH="90%" CELLSPACING=0 CELLPADDING=4>

<tr >

<td class = 'mathema'>
&nbsp;
</td>

<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
LUN
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
MAR
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
MER
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
GIO
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
VEN
</tr>

<tr >

<th class='mathema' scope="row" >
8.00
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
8.50
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#8080FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/3A RIM gruppo FRA L3.php" class="nodecBlack">3A RIM gruppo FRA L3</a> - <a href="../Classi/3C RIM gruppo FRA 3.php" class="nodecBlack">3C RIM gruppo FRA 3</a> - <a href="../Classi/3D RIM gruppo FRA 3.php" class="nodecBlack">3D RIM gruppo FRA 3</a></p>
<p id = 'nodecBlack'>FRA L3</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
9.40
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/5G TUR gruppo FRA 2.php" class="nodecBlack">5G TUR gruppo FRA 2</a></p>
<p id = 'nodecBlack'>FRA L2</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#8080FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/4E TUR gruppo FRA 3.php" class="nodecBlack">4E TUR gruppo FRA 3</a></p>
<p id = 'nodecBlack'>FRA L3</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo FRA 2.php" class="nodecBlack">4D TUR gruppo FRA 2</a></p>
<p id = 'nodecBlack'>FRA L2</p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
10.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#8080FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/4E TUR gruppo FRA 3.php" class="nodecBlack">4E TUR gruppo FRA 3</a></p>
<p id = 'nodecBlack'>FRA L3</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
11.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo FRA 2.php" class="nodecBlack">4D TUR gruppo FRA 2</a></p>
<p id = 'nodecBlack'>FRA L2</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/3E RIM gruppo FRA 2.php" class="nodecBlack">3E RIM gruppo FRA 2</a></p>
<p id = 'nodecBlack'>FRA L2</p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
12.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#8080FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/3A RIM gruppo FRA L3.php" class="nodecBlack">3A RIM gruppo FRA L3</a> - <a href="../Classi/3C RIM gruppo FRA 3.php" class="nodecBlack">3C RIM gruppo FRA 3</a> - <a href="../Classi/3D RIM gruppo FRA 3.php" class="nodecBlack">3D RIM gruppo FRA 3</a></p>
<p id = 'nodecBlack'>FRA L3</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/3E RIM gruppo FRA 2.php" class="nodecBlack">3E RIM gruppo FRA 2</a></p>
<p id = 'nodecBlack'>FRA L2</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/5G TUR gruppo FRA 2.php" class="nodecBlack">5G TUR gruppo FRA 2</a></p>
<p id = 'nodecBlack'>FRA L2</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo FRA 2.php" class="nodecBlack">4D TUR gruppo FRA 2</a></p>
<p id = 'nodecBlack'>FRA L2</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#8080FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/4E TUR gruppo FRA 3.php" class="nodecBlack">4E TUR gruppo FRA 3</a></p>
<p id = 'nodecBlack'>FRA L3</p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
13.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/3E RIM gruppo FRA 2.php" class="nodecBlack">3E RIM gruppo FRA 2</a></p>
<p id = 'nodecBlack'>FRA L2</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/5G TUR gruppo FRA 2.php" class="nodecBlack">5G TUR gruppo FRA 2</a></p>
<p id = 'nodecBlack'>FRA L2</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
14.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#8080FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/3A RIM gruppo FRA L3.php" class="nodecBlack">3A RIM gruppo FRA L3</a> - <a href="../Classi/3C RIM gruppo FRA 3.php" class="nodecBlack">3C RIM gruppo FRA 3</a> - <a href="../Classi/3D RIM gruppo FRA 3.php" class="nodecBlack">3D RIM gruppo FRA 3</a></p>
<p id = 'nodecBlack'>FRA L3</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

</table>



        </div>

<?php include '../footer.html';?>
</body>
</html>
