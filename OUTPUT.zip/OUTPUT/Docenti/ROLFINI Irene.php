<html>
    <head>
        <?php include '../href.html';?>
    </head>
    <body>
        <?php include '../header.html';?>
        <div align="center">
<p class='mathema'>
ORARIO DOCENTE ROLFINI Irene</p>
</div>
    <div align="center">


<table BORDER=2 WIDTH="90%" CELLSPACING=0 CELLPADDING=4>

<tr >

<td class = 'mathema'>
&nbsp;
</td>

<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
LUN
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
MAR
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
MER
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
GIO
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
VEN
</tr>

<tr >

<th class='mathema' scope="row" >
8.00
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
8.50
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
9.40
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
10.40
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
11.30
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
12.30
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
13.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
14.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

</table>



        </div>

<?php include '../footer.html';?>
</body>
</html>
