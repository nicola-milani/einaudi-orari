<html>
    <head>
        <?php include '../href.html';?>
    </head>
    <body>
        <?php include '../header.html';?>
        <div align="center">
<p class='mathema'>
ORARIO DOCENTE BARBIERI Angelo</p>
</div>
    <div align="center">


<table BORDER=2 WIDTH="90%" CELLSPACING=0 CELLPADDING=4>

<tr >

<td class = 'mathema'>
&nbsp;
</td>

<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
LUN
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
MAR
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
MER
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
GIO
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
VEN
</tr>

<tr >

<th class='mathema' scope="row" >
8.00
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
8.50
</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/5G TUR.php" class="nodecBlack">5G TUR</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/4D TUR.php" class="nodecBlack">4D TUR</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
9.40
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
10.40
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/2A AFM.php" class="nodecBlack">2A AFM</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/1H TUR.php" class="nodecBlack">1H TUR</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/1E TUR.php" class="nodecBlack">1E TUR</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
11.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/2D AFM.php" class="nodecBlack">2D AFM</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/3A RIM.php" class="nodecBlack">3A RIM</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/3E RIM.php" class="nodecBlack">3E RIM</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
12.30
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/3C RIM.php" class="nodecBlack">3C RIM</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/1C AFM.php" class="nodecBlack">1C AFM</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/1A AFM.php" class="nodecBlack">1A AFM</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/5E TUR.php" class="nodecBlack">5E TUR</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
13.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/3G TUR.php" class="nodecBlack">3G TUR</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
14.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/1D AFM.php" class="nodecBlack">1D AFM</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/2C AFM.php" class="nodecBlack">2C AFM</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>
<p id = 'nodecBlack'>RELIGIONE</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

</table>



        </div>

<?php include '../footer.html';?>
</body>
</html>
