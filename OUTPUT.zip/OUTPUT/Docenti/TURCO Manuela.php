<html>
    <head>
        <?php include '../href.html';?>
    </head>
    <body>
        <?php include '../header.html';?>
        <div align="center">
<p class='mathema'>
ORARIO DOCENTE TURCO Manuela</p>
</div>
    <div align="center">


<table BORDER=2 WIDTH="90%" CELLSPACING=0 CELLPADDING=4>

<tr >

<td class = 'mathema'>
&nbsp;
</td>

<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
LUN
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
MAR
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
MER
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
GIO
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
VEN
</tr>

<tr >

<th class='mathema' scope="row" >
8.00
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/5G TUR gruppo SPA 3.php" class="nodecBlack">5G TUR gruppo SPA 3</a></p>
<p id = 'nodecBlack'>SPA L3</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/5G TUR gruppo SPA 3.php" class="nodecBlack">5G TUR gruppo SPA 3</a></p>
<p id = 'nodecBlack'>SPA L3</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/3E RIM gruppo SPA 3.php" class="nodecBlack">3E RIM gruppo SPA 3</a></p>
<p id = 'nodecBlack'>SPA L3</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
8.50
</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/5E TUR.php" class="nodecBlack">5E TUR</a></p>
<p id = 'nodecBlack'>SPA L3</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/3E RIM gruppo SPA 3.php" class="nodecBlack">3E RIM gruppo SPA 3</a></p>
<p id = 'nodecBlack'>SPA L3</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/5F TUR.php" class="nodecBlack">5F TUR</a></p>
<p id = 'nodecBlack'>SPA L2</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
9.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/3G TUR gruppo SPA 2.php" class="nodecBlack">3G TUR gruppo SPA 2</a></p>
<p id = 'nodecBlack'>SPA L2</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/5E TUR.php" class="nodecBlack">5E TUR</a></p>
<p id = 'nodecBlack'>SPA L3</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo SPA 3.php" class="nodecBlack">4A RIM gruppo SPA 3</a></p>
<p id = 'nodecBlack'>SPA L3</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/3G TUR gruppo SPA 2.php" class="nodecBlack">3G TUR gruppo SPA 2</a></p>
<p id = 'nodecBlack'>SPA L2</p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
10.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo SPA 3.php" class="nodecBlack">4A RIM gruppo SPA 3</a></p>
<p id = 'nodecBlack'>SPA L3</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/3G TUR gruppo SPA 2.php" class="nodecBlack">3G TUR gruppo SPA 2</a></p>
<p id = 'nodecBlack'>SPA L2</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
11.30
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/5G TUR gruppo SPA 3.php" class="nodecBlack">5G TUR gruppo SPA 3</a></p>
<p id = 'nodecBlack'>SPA L3</p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
12.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/5F TUR.php" class="nodecBlack">5F TUR</a></p>
<p id = 'nodecBlack'>SPA L2</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/5E TUR.php" class="nodecBlack">5E TUR</a></p>
<p id = 'nodecBlack'>SPA L3</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo SPA 3.php" class="nodecBlack">4A RIM gruppo SPA 3</a></p>
<p id = 'nodecBlack'>SPA L3</p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
13.20
</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/3E RIM gruppo SPA 3.php" class="nodecBlack">3E RIM gruppo SPA 3</a></p>
<p id = 'nodecBlack'>SPA L3</p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'><a href="../Classi/5F TUR.php" class="nodecBlack">5F TUR</a></p>
<p id = 'nodecBlack'>SPA L2</p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
14.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

</table>



        </div>

<?php include '../footer.html';?>
</body>
</html>
