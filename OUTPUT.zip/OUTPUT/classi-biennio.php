<!DOCTYPE html>

<HEAD> 
    <?php include 'href.html';?>
</HEAD>

<BODY>
    <div class='header'>
        <?php include 'header.html';?>
    </div>
    <div align="center">
        <div class="responsive">
            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 class="table launch" style="vertical-align: top;">

                <TR VALIGN=TOP>

                    <Th ALIGN=TOP class='mathema'>
                        <b>CLASSI PRIME AFM</b>
                    </Th>
                </tr>
                <tr>
                    <td><A HREF="Classi/1A AFM.php" class='mathema'>1A AFM</A><BR></td>
                </tr>
                <tr>
                    <td><A HREF="Classi/1B AFM.php" class='mathema'>1B AFM</A><BR></td>
                </tr>
                <tr>
                    <td><A HREF="Classi/1C AFM.php" class='mathema'>1C AFM</A><BR></td>
                </tr>
                <tr>
                    <td><A HREF="Classi/1D AFM.php" class='mathema'>1D AFM</A><BR></td>
                </tr>
            </table>

        </div>
        <div class="responsive" style="vertical-align: top;">
            <table class="table launch">
                <tr>
                    <th class='mathema'>
                        <b>CLASSI PRIME TUR</b>
                    </th>
                </tr>
                <tr>
                    <td>
                        <A HREF="Classi/1E TUR.php" class='mathema'>1E TUR</A>
                        <BR>
                    </td>
                </tr>
                <tr>
                    <td>
                        <A HREF="Classi/1F TUR.php" class='mathema'>1F TUR</A>
                        <BR>
                    </td>
                </tr>
                <tr>
                    <td>
                        <A HREF="Classi/1G TUR.php" class='mathema'>1G TUR</A>
                        <BR>
                    </td>
                </tr>
                <tr>
                    <td>
                        <A HREF="Classi/1H TUR.php" class='mathema'>1H TUR</A>
                        <BR>
                    </td>
                </tr>

            </table>
        </div>
        <div class="responsive" style="vertical-align: top;">
            <table class="table launch">
                <tr>
                    <th class='mathema'>
                        <b>CLASSI SECONDE AFM</b>
                    </th>
                </tr>
                <tr>
                    <td>
                        <A HREF="Classi/2A AFM.php" class='mathema'>2A AFM</A>
                        <BR>
                    </td>
                </tr>
                <tr>
                    <td><A HREF="Classi/2B AFM.php" class='mathema'>2B AFM</A>
                        <BR>
                    </td>
                </tr>
                <tr>
                    <td><A HREF="Classi/2C AFM.php" class='mathema'>2C AFM</A>
                        <BR>
                    </td>
                </tr>
                <tr>
                    <td><A HREF="Classi/2D AFM.php" class='mathema'>2D AFM</A>
                        <BR>
                    </td>
                </tr>
                <!--<tr>
                    <td class='mathema'>
                       <A HREF="" class='mathema' disable>-</A>
                        <BR>
                    </td>
                </tr>
                <tr>
                    <td class='mathema'>
                       <A HREF="" class='mathema' disable>-</A>
                        <BR>
                    </td>
                </tr>-->
            </TABLE>
        </div>
        <div class="responsive" style="vertical-align: top;">
            <table class="table launch">

                <TP>

                    <Th ALIGN=TOP class='mathema'>
                        <b>CLASSI SECONDE TUR</b>
                    </Th>
                </tr>
                <tr>
                    <td><A HREF="Classi/2D TUR.php" class='mathema'>2D TUR</A>
                        <BR>
                    </td>
                </tr>
                <tr>
                    <td><A HREF="Classi/2E TUR.php" class='mathema'>2E TUR</A>
                        <BR>
                    </td>
                </tr>
                <tr>
                    <td><A HREF="Classi/2F TUR.php" class='mathema'>2F TUR</A>
                        <BR>
                    </td>
                </tr>
                <tr>
                    <td><A HREF="Classi/2G TUR.php" class='mathema'>2G TUR</A>
                        <BR>
                    </td>
                </tr>
                <tr>
                    <td><A HREF="Classi/2H TUR.php" class='mathema'>2H TUR</A>
                        <BR>
                    </td>
                </tr>
            </TABLE>
        </div>
    </div>

    <?php include 'footer.html';?>
</BODY>

</HTML>