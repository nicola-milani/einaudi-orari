<html>
    <head>
        <?php include '../href.html';?>
    </head>
    <body>
        <?php include '../header.html';?>
        <div align="center">
<p class='mathema'>
ORARIO CLASSE 5A RIM gruppo SPA 3</p>
</div>
    <div align="center">


<table BORDER=2 WIDTH="90%" CELLSPACING=0 CELLPADDING=4>

<tr >

<td class = 'mathema'>
&nbsp;
</td>

<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
LUN
<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
MAR
<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
MER
<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
GIO
<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
VEN
</tr>

<tr >

<th class='mathema' scope="row" >
8.00
</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/CRISTANINI Antonella.php" class="nodecBlack">CRISTANINI Antonella</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a> - <a href="../Aule/palestra A.php" class="nodecBlack">palestra A</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FF80" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELAZ INTERNAZIONALI</p>
<p id = 'nodecBlack'><a href="../Docenti/PELLIZZARI Stefania.php" class="nodecBlack">PELLIZZARI Stefania</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/MAZZANTI Susanna.php" class="nodecBlack">MAZZANTI Susanna</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/CRISTANINI Antonella.php" class="nodecBlack">CRISTANINI Antonella</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a> - <a href="../Aule/palestra B.php" class="nodecBlack">palestra B</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
8.50
</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/MAZZANTI Susanna.php" class="nodecBlack">MAZZANTI Susanna</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/DEL SOLDATO Monica.php" class="nodecBlack">DEL SOLDATO Monica</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/CUESTA Pizarro Guadalupe.php" class="nodecBlack">CUESTA Pizarro Guadalupe</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/MAZZANTI Susanna.php" class="nodecBlack">MAZZANTI Susanna</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0E0E0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO</p>
<p id = 'nodecBlack'><a href="../Docenti/LO CIStrO Guido.php" class="nodecBlack">LO CIStrO Guido</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
9.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#80FF80" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELAZ INTERNAZIONALI</p>
<p id = 'nodecBlack'><a href="../Docenti/PELLIZZARI Stefania.php" class="nodecBlack">PELLIZZARI Stefania</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/CUESTA Pizarro Guadalupe.php" class="nodecBlack">CUESTA Pizarro Guadalupe</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/MAZZANTI Susanna.php" class="nodecBlack">MAZZANTI Susanna</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=2 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/VESENTINI Giorgia.php" class="nodecBlack">VESENTINI Giorgia</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/CUESTA Pizarro Guadalupe.php" class="nodecBlack">CUESTA Pizarro Guadalupe</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
10.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/DEL SOLDATO Monica.php" class="nodecBlack">DEL SOLDATO Monica</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=2 ROWSPAN=2 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/MAZZANTI Susanna.php" class="nodecBlack">MAZZANTI Susanna</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#00FF00" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L2</p>
<p id = 'nodecBlack'><a href="../Docenti/BONELLI Paola.php" class="nodecBlack">BONELLI Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#00FF00" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L2</p>
<p id = 'nodecBlack'><a href="../Docenti/BONELLI Paola.php" class="nodecBlack">BONELLI Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
11.30
</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/CARUSO Maria.php" class="nodecWhite">CARUSO Maria</a></p>
<p id = 'nodecWhite'><a href="../Classi/5A RIM.php" class="nodecWhite">5A RIM</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/CARUSO Maria.php" class="nodecWhite">CARUSO Maria</a></p>
<p id = 'nodecWhite'><a href="../Classi/5A RIM.php" class="nodecWhite">5A RIM</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/CARUSO Maria.php" class="nodecWhite">CARUSO Maria</a></p>
<p id = 'nodecWhite'><a href="../Classi/5A RIM.php" class="nodecWhite">5A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/DEL SOLDATO Monica.php" class="nodecBlack">DEL SOLDATO Monica</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
12.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/VESENTINI Giorgia.php" class="nodecBlack">VESENTINI Giorgia</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/VESENTINI Giorgia.php" class="nodecBlack">VESENTINI Giorgia</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/VESENTINI Giorgia.php" class="nodecBlack">VESENTINI Giorgia</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FF80" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELAZ INTERNAZIONALI</p>
<p id = 'nodecBlack'><a href="../Docenti/PELLIZZARI Stefania.php" class="nodecBlack">PELLIZZARI Stefania</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/VESENTINI Giorgia.php" class="nodecBlack">VESENTINI Giorgia</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
13.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0E0E0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO</p>
<p id = 'nodecBlack'><a href="../Docenti/LO CIStrO Guido.php" class="nodecBlack">LO CIStrO Guido</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#00FF00" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L2</p>
<p id = 'nodecBlack'><a href="../Docenti/BONELLI Paola.php" class="nodecBlack">BONELLI Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
14.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELIGIONE</p>
<p id = 'nodecBlack'><a href="../Docenti/BARBIERI Angelo.php" class="nodecBlack">BARBIERI Angelo</a></p>
<p id = 'nodecBlack'><a href="../Classi/5A RIM.php" class="nodecBlack">5A RIM</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

</table>



        </div>

<?php include '../footer.html';?>
</body>
</html>
