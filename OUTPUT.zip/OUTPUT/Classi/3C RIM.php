<html>
    <head>
        <?php include '../href.html';?>
    </head>
    <body>
        <?php include '../header.html';?>
        <div align="center">
<p class='mathema'>
ORARIO CLASSE 3C RIM</p>
</div>
    <div align="center">


<table BORDER=2 WIDTH="90%" CELLSPACING=0 CELLPADDING=4>

<tr >

<td class = 'mathema'>
&nbsp;
</td>

<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
LUN
<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
MAR
<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
MER
<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
GIO
<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
VEN
</tr>

<tr >

<th class='mathema' scope="row" >
8.00
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/CUESTA Pizarro Guadalupe.php" class="nodecBlack">CUESTA Pizarro Guadalupe</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/MARZANO Fabio.php" class="nodecWhite">MARZANO Fabio</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
8.50
</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/CUESTA Pizarro Guadalupe.php" class="nodecBlack">CUESTA Pizarro Guadalupe</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#8080FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>FRA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/CADDEO Rita Paola.php" class="nodecBlack">CADDEO Rita Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/3A RIM gruppo FRA L3.php" class="nodecBlack">3A RIM gruppo FRA L3</a> - <a href="../Classi/3C RIM gruppo FRA 3.php" class="nodecBlack">3C RIM gruppo FRA 3</a> - <a href="../Classi/3D RIM gruppo FRA 3.php" class="nodecBlack">3D RIM gruppo FRA 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L3</p>
<p id = 'nodecBlack'><a href="../Docenti/SORDILLO Edvige.php" class="nodecBlack">SORDILLO Edvige</a></p>
<p id = 'nodecBlack'><a href="../Classi/3C RIM gruppo TED 3.php" class="nodecBlack">3C RIM gruppo TED 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/GRIGATO Cesare.php" class="nodecBlack">GRIGATO Cesare</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/BENATI FEZZI Marta.php" class="nodecBlack">BENATI FEZZI Marta</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/CUESTA Pizarro Guadalupe.php" class="nodecBlack">CUESTA Pizarro Guadalupe</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
9.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#80FF80" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELAZ INTERNAZIONALI</p>
<p id = 'nodecBlack'><a href="../Docenti/DE ROSIS Amalia.php" class="nodecBlack">DE ROSIS Amalia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=2 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/BENATI FEZZI Marta.php" class="nodecBlack">BENATI FEZZI Marta</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/GRIGATO Cesare.php" class="nodecBlack">GRIGATO Cesare</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/BARES Camilla.php" class="nodecBlack">BARES Camilla</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/SALVADORI Ilaria.php" class="nodecBlack">SALVADORI Ilaria</a> - <a href="../Aule/palestra A.php" class="nodecBlack">palestra A</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
10.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/GRIGATO Cesare.php" class="nodecBlack">GRIGATO Cesare</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#FF00FF" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>TEC. COMUNICAZIONI</p>
<p id = 'nodecWhite'><a href="../Docenti/FEDERICO Maria.php" class="nodecWhite">FEDERICO Maria</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/GRIGATO Cesare.php" class="nodecBlack">GRIGATO Cesare</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FF80" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELAZ INTERNAZIONALI</p>
<p id = 'nodecBlack'><a href="../Docenti/DE ROSIS Amalia.php" class="nodecBlack">DE ROSIS Amalia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
11.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/BENATI FEZZI Marta.php" class="nodecBlack">BENATI FEZZI Marta</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/MARZANO Fabio.php" class="nodecWhite">MARZANO Fabio</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/BARES Camilla.php" class="nodecBlack">BARES Camilla</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#FF00FF" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>TEC. COMUNICAZIONI</p>
<p id = 'nodecWhite'><a href="../Docenti/FEDERICO Maria.php" class="nodecWhite">FEDERICO Maria</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/BENATI FEZZI Marta.php" class="nodecBlack">BENATI FEZZI Marta</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
12.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#8080FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>FRA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/CADDEO Rita Paola.php" class="nodecBlack">CADDEO Rita Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/3A RIM gruppo FRA L3.php" class="nodecBlack">3A RIM gruppo FRA L3</a> - <a href="../Classi/3C RIM gruppo FRA 3.php" class="nodecBlack">3C RIM gruppo FRA 3</a> - <a href="../Classi/3D RIM gruppo FRA 3.php" class="nodecBlack">3D RIM gruppo FRA 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L3</p>
<p id = 'nodecBlack'><a href="../Docenti/SORDILLO Edvige.php" class="nodecBlack">SORDILLO Edvige</a></p>
<p id = 'nodecBlack'><a href="../Classi/3C RIM gruppo TED 3.php" class="nodecBlack">3C RIM gruppo TED 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELIGIONE</p>
<p id = 'nodecBlack'><a href="../Docenti/BARBIERI Angelo.php" class="nodecBlack">BARBIERI Angelo</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/BENATI FEZZI Marta.php" class="nodecBlack">BENATI FEZZI Marta</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0E0E0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO</p>
<p id = 'nodecBlack'><a href="../Docenti/DE ROSIS Amalia.php" class="nodecBlack">DE ROSIS Amalia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0E0E0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO</p>
<p id = 'nodecBlack'><a href="../Docenti/DE ROSIS Amalia.php" class="nodecBlack">DE ROSIS Amalia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
13.20
</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/GRIGATO Cesare.php" class="nodecBlack">GRIGATO Cesare</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/SALVADORI Ilaria.php" class="nodecBlack">SALVADORI Ilaria</a> - <a href="../Aule/palestra B.php" class="nodecBlack">palestra B</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/BARES Camilla.php" class="nodecBlack">BARES Camilla</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
14.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#8080FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>FRA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/CADDEO Rita Paola.php" class="nodecBlack">CADDEO Rita Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/3A RIM gruppo FRA L3.php" class="nodecBlack">3A RIM gruppo FRA L3</a> - <a href="../Classi/3C RIM gruppo FRA 3.php" class="nodecBlack">3C RIM gruppo FRA 3</a> - <a href="../Classi/3D RIM gruppo FRA 3.php" class="nodecBlack">3D RIM gruppo FRA 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L3</p>
<p id = 'nodecBlack'><a href="../Docenti/SORDILLO Edvige.php" class="nodecBlack">SORDILLO Edvige</a></p>
<p id = 'nodecBlack'><a href="../Classi/3C RIM gruppo TED 3.php" class="nodecBlack">3C RIM gruppo TED 3</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/MARZANO Fabio.php" class="nodecWhite">MARZANO Fabio</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

</table>



        </div>

<?php include '../footer.html';?>
</body>
</html>
