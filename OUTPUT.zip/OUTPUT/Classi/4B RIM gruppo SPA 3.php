<html>
    <head>
        <?php include '../href.html';?>
    </head>
    <body>
        <?php include '../header.html';?>
        <div align="center">
<p class='mathema'>
ORARIO CLASSE 4B RIM gruppo SPA 3</p>
</div>
    <div align="center">


<table BORDER=2 WIDTH="90%" CELLSPACING=0 CELLPADDING=4>

<tr >

<td class = 'mathema'>
&nbsp;
</td>

<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
LUN
<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
MAR
<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
MER
<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
GIO
<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
VEN
</tr>

<tr >

<th class='mathema' scope="row" >
8.00
</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/ZAFFANI Stefania.php" class="nodecBlack">ZAFFANI Stefania</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/ZAFFANI Stefania.php" class="nodecBlack">ZAFFANI Stefania</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
8.50
</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/PARISI Mario.php" class="nodecWhite">PARISI Mario</a></p>
<p id = 'nodecWhite'><a href="../Classi/4B RIM.php" class="nodecWhite">4B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FF80" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELAZ INTERNAZIONALI</p>
<p id = 'nodecBlack'><a href="../Docenti/OTTAVIANO Clara.php" class="nodecBlack">OTTAVIANO Clara</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/COMENCINI Cinzia.php" class="nodecBlack">COMENCINI Cinzia</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a> - <a href="../Aule/palestra B.php" class="nodecBlack">palestra B</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/MORO Margherita.php" class="nodecBlack">MORO Margherita</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/ZAFFANI Stefania.php" class="nodecBlack">ZAFFANI Stefania</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
9.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>FRA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/FULLY Veronique.php" class="nodecBlack">FULLY Veronique</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM gruppo FRA 2.php" class="nodecBlack">4B RIM gruppo FRA 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#00FF00" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L2</p>
<p id = 'nodecBlack'><a href="../Docenti/BONELLI Paola.php" class="nodecBlack">BONELLI Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM gruppo TED 2.php" class="nodecBlack">4B RIM gruppo TED 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=2 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/ZAFFANI Stefania.php" class="nodecBlack">ZAFFANI Stefania</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/ZAFFANI Stefania.php" class="nodecBlack">ZAFFANI Stefania</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/CUESTA Pizarro Guadalupe.php" class="nodecBlack">CUESTA Pizarro Guadalupe</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#FF00FF" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>TEC. COMUNICAZIONI</p>
<p id = 'nodecWhite'><a href="../Docenti/FEDERICO Maria.php" class="nodecWhite">FEDERICO Maria</a></p>
<p id = 'nodecWhite'><a href="../Classi/4B RIM.php" class="nodecWhite">4B RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
10.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/CUESTA Pizarro Guadalupe.php" class="nodecBlack">CUESTA Pizarro Guadalupe</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/PARISI Mario.php" class="nodecWhite">PARISI Mario</a></p>
<p id = 'nodecWhite'><a href="../Classi/4B RIM.php" class="nodecWhite">4B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FF80" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELAZ INTERNAZIONALI</p>
<p id = 'nodecBlack'><a href="../Docenti/OTTAVIANO Clara.php" class="nodecBlack">OTTAVIANO Clara</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/FALAUTO Giovanna.php" class="nodecBlack">FALAUTO Giovanna</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
11.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/COMENCINI Cinzia.php" class="nodecBlack">COMENCINI Cinzia</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a> - <a href="../Aule/palestra A.php" class="nodecBlack">palestra A</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/FALAUTO Giovanna.php" class="nodecBlack">FALAUTO Giovanna</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELIGIONE</p>
<p id = 'nodecBlack'><a href="../Docenti/LIGORIO Marco.php" class="nodecBlack">LIGORIO Marco</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/FALAUTO Giovanna.php" class="nodecBlack">FALAUTO Giovanna</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/FALAUTO Giovanna.php" class="nodecBlack">FALAUTO Giovanna</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
12.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#C0E0E0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO</p>
<p id = 'nodecBlack'><a href="../Docenti/LO CIStrO Guido.php" class="nodecBlack">LO CIStrO Guido</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#FF00FF" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>TEC. COMUNICAZIONI</p>
<p id = 'nodecWhite'><a href="../Docenti/FEDERICO Maria.php" class="nodecWhite">FEDERICO Maria</a></p>
<p id = 'nodecWhite'><a href="../Classi/4B RIM.php" class="nodecWhite">4B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>FRA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/FULLY Veronique.php" class="nodecBlack">FULLY Veronique</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM gruppo FRA 2.php" class="nodecBlack">4B RIM gruppo FRA 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#00FF00" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L2</p>
<p id = 'nodecBlack'><a href="../Docenti/BONELLI Paola.php" class="nodecBlack">BONELLI Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM gruppo TED 2.php" class="nodecBlack">4B RIM gruppo TED 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0E0E0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO</p>
<p id = 'nodecBlack'><a href="../Docenti/LO CIStrO Guido.php" class="nodecBlack">LO CIStrO Guido</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/CUESTA Pizarro Guadalupe.php" class="nodecBlack">CUESTA Pizarro Guadalupe</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
13.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/PARISI Mario.php" class="nodecWhite">PARISI Mario</a></p>
<p id = 'nodecWhite'><a href="../Classi/4B RIM.php" class="nodecWhite">4B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/MORO Margherita.php" class="nodecBlack">MORO Margherita</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>FRA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/FULLY Veronique.php" class="nodecBlack">FULLY Veronique</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM gruppo FRA 2.php" class="nodecBlack">4B RIM gruppo FRA 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#00FF00" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L2</p>
<p id = 'nodecBlack'><a href="../Docenti/BONELLI Paola.php" class="nodecBlack">BONELLI Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM gruppo TED 2.php" class="nodecBlack">4B RIM gruppo TED 2</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
14.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/FALAUTO Giovanna.php" class="nodecBlack">FALAUTO Giovanna</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/MORO Margherita.php" class="nodecBlack">MORO Margherita</a></p>
<p id = 'nodecBlack'><a href="../Classi/4B RIM.php" class="nodecBlack">4B RIM</a></p>

</td>

</tr>

</table>



        </div>

<?php include '../footer.html';?>
</body>
</html>
