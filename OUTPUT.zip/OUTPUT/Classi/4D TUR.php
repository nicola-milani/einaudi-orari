<html>
    <head>
        <?php include '../href.html';?>
    </head>
    <body>
        <?php include '../header.html';?>
        <div align="center">
<p class='mathema'>
ORARIO CLASSE 4D TUR</p>
</div>
    <div align="center">


<table BORDER=2 WIDTH="90%" CELLSPACING=0 CELLPADDING=4>

<tr >

<td class = 'mathema'>
&nbsp;
</td>

<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
LUN
<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
MAR
<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
MER
<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
GIO
<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
VEN
</tr>

<tr >

<th class='mathema' scope="row" >
8.00
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/PARISI Mario.php" class="nodecWhite">PARISI Mario</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/OLIVERI Patrizia.php" class="nodecBlack">OLIVERI Patrizia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
8.50
</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8000" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>GEO TURISTICA</p>
<p id = 'nodecBlack'><a href="../Docenti/RAD Olimpia Mirela.php" class="nodecBlack">RAD Olimpia Mirela</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELIGIONE</p>
<p id = 'nodecBlack'><a href="../Docenti/BARBIERI Angelo.php" class="nodecBlack">BARBIERI Angelo</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#D0C0FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO e LEG. TUR1</p>
<p id = 'nodecBlack'><a href="../Docenti/DE ROSIS Amalia.php" class="nodecBlack">DE ROSIS Amalia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/PARISI Mario.php" class="nodecWhite">PARISI Mario</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#FF4040" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>DTA</p>
<p id = 'nodecWhite'><a href="../Docenti/ROTONDALE Maria.php" class="nodecWhite">ROTONDALE Maria</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
9.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/BARES Camilla.php" class="nodecBlack">BARES Camilla</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#D0C0FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO e LEG. TUR1</p>
<p id = 'nodecBlack'><a href="../Docenti/DE ROSIS Amalia.php" class="nodecBlack">DE ROSIS Amalia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/CAVALLINI Egidio.php" class="nodecBlack">CAVALLINI Egidio</a> - <a href="../Aule/palestra A.php" class="nodecBlack">palestra A</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/DE CARO Sofia.php" class="nodecBlack">DE CARO Sofia</a></p>
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo SPA 3.php" class="nodecBlack">4D TUR gruppo SPA 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L3</p>
<p id = 'nodecBlack'><a href="../Docenti/BONELLI Paola.php" class="nodecBlack">BONELLI Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo TED 3.php" class="nodecBlack">4D TUR gruppo TED 3</a> - <a href="../Classi/4E TUR gruppo TED 3.php" class="nodecBlack">4E TUR gruppo TED 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>FRA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/CADDEO Rita Paola.php" class="nodecBlack">CADDEO Rita Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo FRA 2.php" class="nodecBlack">4D TUR gruppo FRA 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#00FF00" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L2</p>
<p id = 'nodecBlack'><a href="../Docenti/SORDILLO Edvige.php" class="nodecBlack">SORDILLO Edvige</a></p>
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo TED 2.php" class="nodecBlack">4D TUR gruppo TED 2</a> - <a href="../Classi/4E TUR gruppo TED 2.php" class="nodecBlack">4E TUR gruppo TED 2</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
10.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/DE CARO Sofia.php" class="nodecBlack">DE CARO Sofia</a></p>
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo SPA 3.php" class="nodecBlack">4D TUR gruppo SPA 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L3</p>
<p id = 'nodecBlack'><a href="../Docenti/BONELLI Paola.php" class="nodecBlack">BONELLI Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo TED 3.php" class="nodecBlack">4D TUR gruppo TED 3</a> - <a href="../Classi/4E TUR gruppo TED 3.php" class="nodecBlack">4E TUR gruppo TED 3</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/PARISI Mario.php" class="nodecWhite">PARISI Mario</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=2 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/OLIVERI Patrizia.php" class="nodecBlack">OLIVERI Patrizia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/OLIVERI Patrizia.php" class="nodecBlack">OLIVERI Patrizia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8000" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>GEO TURISTICA</p>
<p id = 'nodecBlack'><a href="../Docenti/RAD Olimpia Mirela.php" class="nodecBlack">RAD Olimpia Mirela</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
11.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>FRA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/CADDEO Rita Paola.php" class="nodecBlack">CADDEO Rita Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo FRA 2.php" class="nodecBlack">4D TUR gruppo FRA 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#00FF00" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L2</p>
<p id = 'nodecBlack'><a href="../Docenti/SORDILLO Edvige.php" class="nodecBlack">SORDILLO Edvige</a></p>
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo TED 2.php" class="nodecBlack">4D TUR gruppo TED 2</a> - <a href="../Classi/4E TUR gruppo TED 2.php" class="nodecBlack">4E TUR gruppo TED 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/BARES Camilla.php" class="nodecBlack">BARES Camilla</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/OLIVERI Patrizia.php" class="nodecBlack">OLIVERI Patrizia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/BARES Camilla.php" class="nodecBlack">BARES Camilla</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
12.30
</td>

<td class = 'nodecWhite'  BGCOLOR="#FF4040" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>DTA</p>
<p id = 'nodecWhite'><a href="../Docenti/ROTONDALE Maria.php" class="nodecWhite">ROTONDALE Maria</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#FF4040" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>DTA</p>
<p id = 'nodecWhite'><a href="../Docenti/ROTONDALE Maria.php" class="nodecWhite">ROTONDALE Maria</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFC0C0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>ARTE e TERRITORIO</p>
<p id = 'nodecBlack'><a href="../Docenti/COMELLI Giulia.php" class="nodecBlack">COMELLI Giulia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>FRA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/CADDEO Rita Paola.php" class="nodecBlack">CADDEO Rita Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo FRA 2.php" class="nodecBlack">4D TUR gruppo FRA 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#00FF00" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L2</p>
<p id = 'nodecBlack'><a href="../Docenti/SORDILLO Edvige.php" class="nodecBlack">SORDILLO Edvige</a></p>
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo TED 2.php" class="nodecBlack">4D TUR gruppo TED 2</a> - <a href="../Classi/4E TUR gruppo TED 2.php" class="nodecBlack">4E TUR gruppo TED 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/DE CARO Sofia.php" class="nodecBlack">DE CARO Sofia</a></p>
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo SPA 3.php" class="nodecBlack">4D TUR gruppo SPA 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA000" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L3</p>
<p id = 'nodecBlack'><a href="../Docenti/BONELLI Paola.php" class="nodecBlack">BONELLI Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo TED 3.php" class="nodecBlack">4D TUR gruppo TED 3</a> - <a href="../Classi/4E TUR gruppo TED 3.php" class="nodecBlack">4E TUR gruppo TED 3</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
13.20
</td>

<td class = 'nodecWhite'  BGCOLOR="#FF4040" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>DTA</p>
<p id = 'nodecWhite'><a href="../Docenti/ROTONDALE Maria.php" class="nodecWhite">ROTONDALE Maria</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/OLIVERI Patrizia.php" class="nodecBlack">OLIVERI Patrizia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#D0C0FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO e LEG. TUR1</p>
<p id = 'nodecBlack'><a href="../Docenti/DE ROSIS Amalia.php" class="nodecBlack">DE ROSIS Amalia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
14.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFC0C0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>ARTE e TERRITORIO</p>
<p id = 'nodecBlack'><a href="../Docenti/COMELLI Giulia.php" class="nodecBlack">COMELLI Giulia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/CAVALLINI Egidio.php" class="nodecBlack">CAVALLINI Egidio</a> - <a href="../Aule/palestra B.php" class="nodecBlack">palestra B</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

</table>



        </div>

<?php include '../footer.html';?>
</body>
</html>
