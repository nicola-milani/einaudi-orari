<html>
    <head>
        <?php include '../href.html';?>
    </head>
    <body>
        <?php include '../header.html';?>
        <div align="center">
<p class='mathema'>
ORARIO CLASSE 4A RIM gruppo SPA 2</p>
</div>
    <div align="center">


<table BORDER=2 WIDTH="90%" CELLSPACING=0 CELLPADDING=4>

<tr >

<td class = 'mathema'>
&nbsp;
</td>

<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
LUN
<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
MAR
<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
MER
<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
GIO
<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
VEN
</tr>

<tr >

<th class='mathema' scope="row" >
8.00
</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/BERNI Rossana.php" class="nodecWhite">BERNI Rossana</a></p>
<p id = 'nodecWhite'><a href="../Classi/4A RIM.php" class="nodecWhite">4A RIM</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/MAZZANTI Susanna.php" class="nodecBlack">MAZZANTI Susanna</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
8.50
</td>

<td class = 'nodecBlack'  BGCOLOR="#C0E0E0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO</p>
<p id = 'nodecBlack'><a href="../Docenti/OTTAVIANO Clara.php" class="nodecBlack">OTTAVIANO Clara</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/BERNI Rossana.php" class="nodecWhite">BERNI Rossana</a></p>
<p id = 'nodecWhite'><a href="../Classi/4A RIM.php" class="nodecWhite">4A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/MAZZANTI Susanna.php" class="nodecBlack">MAZZANTI Susanna</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/CUESTA Pizarro Guadalupe.php" class="nodecBlack">CUESTA Pizarro Guadalupe</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C RIM gruppo SPA 2.php" class="nodecBlack">4C RIM gruppo SPA 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/MARANI Daniela.php" class="nodecBlack">MARANI Daniela</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
9.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/DEL SOLDATO Monica.php" class="nodecBlack">DEL SOLDATO Monica</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/CRISTANINI Antonella.php" class="nodecBlack">CRISTANINI Antonella</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a> - <a href="../Aule/palestra B.php" class="nodecBlack">palestra B</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/CUESTA Pizarro Guadalupe.php" class="nodecBlack">CUESTA Pizarro Guadalupe</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C RIM gruppo SPA 2.php" class="nodecBlack">4C RIM gruppo SPA 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0FFC0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>CIN L3</p>
<p id = 'nodecBlack'><a href="../Docenti/PITTORE Maria Nunzia.php" class="nodecBlack">PITTORE Maria Nunzia</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo CIN 3.php" class="nodecBlack">4A RIM gruppo CIN 3</a> - <a href="../Classi/4B RIM gruppo CIN 3.php" class="nodecBlack">4B RIM gruppo CIN 3</a> - <a href="../Classi/4C RIM gruppo CIN 3.php" class="nodecBlack">4C RIM gruppo CIN 3</a> - <a href="../Classi/4E TUR gruppo CIN 3.php" class="nodecBlack">4E TUR gruppo CIN 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/TURCO Manuela.php" class="nodecBlack">TURCO Manuela</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo SPA 3.php" class="nodecBlack">4A RIM gruppo SPA 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA000" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L3</p>
<p id = 'nodecBlack'><a href="../Docenti/MARCONCINI Monica.php" class="nodecBlack">MARCONCINI Monica</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo TED 3.php" class="nodecBlack">4A RIM gruppo TED 3</a> - <a href="../Classi/4B RIM gruppo TED 3.php" class="nodecBlack">4B RIM gruppo TED 3</a> - <a href="../Classi/4C RIM gruppo TED 3.php" class="nodecBlack">4C RIM gruppo TED 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FF80" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELAZ INTERNAZIONALI</p>
<p id = 'nodecBlack'><a href="../Docenti/OTTAVIANO Clara.php" class="nodecBlack">OTTAVIANO Clara</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
10.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#C0FFC0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>CIN L3</p>
<p id = 'nodecBlack'><a href="../Docenti/PITTORE Maria Nunzia.php" class="nodecBlack">PITTORE Maria Nunzia</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo CIN 3.php" class="nodecBlack">4A RIM gruppo CIN 3</a> - <a href="../Classi/4B RIM gruppo CIN 3.php" class="nodecBlack">4B RIM gruppo CIN 3</a> - <a href="../Classi/4C RIM gruppo CIN 3.php" class="nodecBlack">4C RIM gruppo CIN 3</a> - <a href="../Classi/4E TUR gruppo CIN 3.php" class="nodecBlack">4E TUR gruppo CIN 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/TURCO Manuela.php" class="nodecBlack">TURCO Manuela</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo SPA 3.php" class="nodecBlack">4A RIM gruppo SPA 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA000" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L3</p>
<p id = 'nodecBlack'><a href="../Docenti/MARCONCINI Monica.php" class="nodecBlack">MARCONCINI Monica</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo TED 3.php" class="nodecBlack">4A RIM gruppo TED 3</a> - <a href="../Classi/4B RIM gruppo TED 3.php" class="nodecBlack">4B RIM gruppo TED 3</a> - <a href="../Classi/4C RIM gruppo TED 3.php" class="nodecBlack">4C RIM gruppo TED 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/DEL SOLDATO Monica.php" class="nodecBlack">DEL SOLDATO Monica</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=2 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/MARANI Daniela.php" class="nodecBlack">MARANI Daniela</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/MARANI Daniela.php" class="nodecBlack">MARANI Daniela</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/MAZZANTI Susanna.php" class="nodecBlack">MAZZANTI Susanna</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
11.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/MARANI Daniela.php" class="nodecBlack">MARANI Daniela</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/CUESTA Pizarro Guadalupe.php" class="nodecBlack">CUESTA Pizarro Guadalupe</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C RIM gruppo SPA 2.php" class="nodecBlack">4C RIM gruppo SPA 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0E0E0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO</p>
<p id = 'nodecBlack'><a href="../Docenti/OTTAVIANO Clara.php" class="nodecBlack">OTTAVIANO Clara</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/MAZZANTI Susanna.php" class="nodecBlack">MAZZANTI Susanna</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
12.30
</td>

<td class = 'nodecWhite'  BGCOLOR="#FF00FF" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>TEC. COMUNICAZIONI</p>
<p id = 'nodecWhite'><a href="../Docenti/FEDERICO Maria.php" class="nodecWhite">FEDERICO Maria</a></p>
<p id = 'nodecWhite'><a href="../Classi/4A RIM.php" class="nodecWhite">4A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/MAZZANTI Susanna.php" class="nodecBlack">MAZZANTI Susanna</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/BERNI Rossana.php" class="nodecWhite">BERNI Rossana</a></p>
<p id = 'nodecWhite'><a href="../Classi/4A RIM.php" class="nodecWhite">4A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/DEL SOLDATO Monica.php" class="nodecBlack">DEL SOLDATO Monica</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0FFC0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>CIN L3</p>
<p id = 'nodecBlack'><a href="../Docenti/PITTORE Maria Nunzia.php" class="nodecBlack">PITTORE Maria Nunzia</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo CIN 3.php" class="nodecBlack">4A RIM gruppo CIN 3</a> - <a href="../Classi/4B RIM gruppo CIN 3.php" class="nodecBlack">4B RIM gruppo CIN 3</a> - <a href="../Classi/4C RIM gruppo CIN 3.php" class="nodecBlack">4C RIM gruppo CIN 3</a> - <a href="../Classi/4E TUR gruppo CIN 3.php" class="nodecBlack">4E TUR gruppo CIN 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/TURCO Manuela.php" class="nodecBlack">TURCO Manuela</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo SPA 3.php" class="nodecBlack">4A RIM gruppo SPA 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA000" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L3</p>
<p id = 'nodecBlack'><a href="../Docenti/MARCONCINI Monica.php" class="nodecBlack">MARCONCINI Monica</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo TED 3.php" class="nodecBlack">4A RIM gruppo TED 3</a> - <a href="../Classi/4B RIM gruppo TED 3.php" class="nodecBlack">4B RIM gruppo TED 3</a> - <a href="../Classi/4C RIM gruppo TED 3.php" class="nodecBlack">4C RIM gruppo TED 3</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
13.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#FF00FF" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>TEC. COMUNICAZIONI</p>
<p id = 'nodecWhite'><a href="../Docenti/FEDERICO Maria.php" class="nodecWhite">FEDERICO Maria</a></p>
<p id = 'nodecWhite'><a href="../Classi/4A RIM.php" class="nodecWhite">4A RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/CRISTANINI Antonella.php" class="nodecBlack">CRISTANINI Antonella</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a> - <a href="../Aule/palestra A.php" class="nodecBlack">palestra A</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELIGIONE</p>
<p id = 'nodecBlack'><a href="../Docenti/BARBIERI Angelo.php" class="nodecBlack">BARBIERI Angelo</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
14.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FF80" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELAZ INTERNAZIONALI</p>
<p id = 'nodecBlack'><a href="../Docenti/OTTAVIANO Clara.php" class="nodecBlack">OTTAVIANO Clara</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/MARANI Daniela.php" class="nodecBlack">MARANI Daniela</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM.php" class="nodecBlack">4A RIM</a></p>

</td>

</tr>

</table>



        </div>

<?php include '../footer.html';?>
</body>
</html>
