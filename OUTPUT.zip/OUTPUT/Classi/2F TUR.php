<html>
    <head>
        <?php include '../href.html';?>
    </head>
    <body>
        <?php include '../header.html';?>
        <div align="center">
<p class='mathema'>
ORARIO CLASSE 2F TUR</p>
</div>
    <div align="center">


<table BORDER=2 WIDTH="90%" CELLSPACING=0 CELLPADDING=4>

<tr >

<td class = 'mathema'>
&nbsp;
</td>

<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
LUN
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
MAR
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
MER
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
GIO
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
VEN
</tr>

<tr >

<th class='mathema' scope="row" >
8.00
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/ARMILLOTTA Raffaella.php" class="nodecBlack">ARMILLOTTA Raffaella</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA0FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>GEOGRAFIA</p>
<p id = 'nodecBlack'><a href="../Docenti/RAD Olimpia Mirela.php" class="nodecBlack">RAD Olimpia Mirela</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
8.50
</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/CARUSO Maria.php" class="nodecWhite">CARUSO Maria</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/CARUSO Maria.php" class="nodecWhite">CARUSO Maria</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#00A0A0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE</p>
<p id = 'nodecBlack'><a href="../Docenti/DE GAETANO Maria Carmela.php" class="nodecBlack">DE GAETANO Maria Carmela</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/ARMILLOTTA Raffaella.php" class="nodecBlack">ARMILLOTTA Raffaella</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/ARMILLOTTA Raffaella.php" class="nodecBlack">ARMILLOTTA Raffaella</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
9.40
</td>

<td class = 'nodecWhite'  BGCOLOR="#0000FF" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>SCIENZE</p>
<p id = 'nodecWhite'><a href="../Docenti/COELLI Monica.php" class="nodecWhite">COELLI Monica</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8040" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO ED ECONOMIA</p>
<p id = 'nodecBlack'><a href="../Docenti/BENATI Silvia.php" class="nodecBlack">BENATI Silvia</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0000FF" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>SCIENZE</p>
<p id = 'nodecWhite'><a href="../Docenti/COELLI Monica.php" class="nodecWhite">COELLI Monica</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0000FF" COLSPAN=1 ROWSPAN=2 COLOR="#FFFFFF">
<p id = 'nodecWhite'>SCIENZE</p>
<p id = 'nodecWhite'><a href="../Docenti/COELLI Monica.php" class="nodecWhite">COELLI Monica</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF70FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INFORMATICA</p>
<p id = 'nodecBlack'><a href="../Docenti/VACCARI Davide.php" class="nodecBlack">VACCARI Davide</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
10.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/COMENCINI Cinzia.php" class="nodecBlack">COMENCINI Cinzia</a> - <a href="../Aule/palestra B.php" class="nodecBlack">palestra B</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/CARUSO Maria.php" class="nodecWhite">CARUSO Maria</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/ARMILLOTTA Raffaella.php" class="nodecBlack">ARMILLOTTA Raffaella</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/MORO Margherita.php" class="nodecBlack">MORO Margherita</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
11.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/MORO Margherita.php" class="nodecBlack">MORO Margherita</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA0FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>GEOGRAFIA</p>
<p id = 'nodecBlack'><a href="../Docenti/RAD Olimpia Mirela.php" class="nodecBlack">RAD Olimpia Mirela</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8040" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO ED ECONOMIA</p>
<p id = 'nodecBlack'><a href="../Docenti/BENATI Silvia.php" class="nodecBlack">BENATI Silvia</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/COMENCINI Cinzia.php" class="nodecBlack">COMENCINI Cinzia</a> - <a href="../Aule/palestra A.php" class="nodecBlack">palestra A</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#FF0080" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>SPAGNOLO</p>
<p id = 'nodecWhite'><a href="../Docenti/DI MAIUTA Anna.php" class="nodecWhite">DI MAIUTA Anna</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
12.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=1 ROWSPAN=2 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/ARMILLOTTA Raffaella.php" class="nodecBlack">ARMILLOTTA Raffaella</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#FF0080" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>SPAGNOLO</p>
<p id = 'nodecWhite'><a href="../Docenti/DI MAIUTA Anna.php" class="nodecWhite">DI MAIUTA Anna</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF70FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INFORMATICA</p>
<p id = 'nodecBlack'><a href="../Docenti/VACCARI Davide.php" class="nodecBlack">VACCARI Davide</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/MORO Margherita.php" class="nodecBlack">MORO Margherita</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#00A0A0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE</p>
<p id = 'nodecBlack'><a href="../Docenti/DE GAETANO Maria Carmela.php" class="nodecBlack">DE GAETANO Maria Carmela</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
13.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA0FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>GEOGRAFIA</p>
<p id = 'nodecBlack'><a href="../Docenti/RAD Olimpia Mirela.php" class="nodecBlack">RAD Olimpia Mirela</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/CARUSO Maria.php" class="nodecWhite">CARUSO Maria</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
14.20
</td>

<td class = 'nodecWhite'  BGCOLOR="#FF0080" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>SPAGNOLO</p>
<p id = 'nodecWhite'><a href="../Docenti/DI MAIUTA Anna.php" class="nodecWhite">DI MAIUTA Anna</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELIGIONE</p>
<p id = 'nodecBlack'><a href="../Docenti/LIGORIO Marco.php" class="nodecBlack">LIGORIO Marco</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

</table>



        </div>

<?php include '../footer.html';?>
</body>
</html>
