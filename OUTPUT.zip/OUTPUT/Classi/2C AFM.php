<html>
    <head>
        <?php include '../href.html';?>
    </head>
    <body>
        <?php include '../header.html';?>
        <div align="center">
<p class='mathema'>
ORARIO CLASSE 2C AFM</p>
</div>
    <div align="center">


<table BORDER=2 WIDTH="90%" CELLSPACING=0 CELLPADDING=4>

<tr >

<td class = 'mathema'>
&nbsp;
</td>

<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
LUN
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
MAR
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
MER
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
GIO
<td class = 'mathema'   COLSPAN=1 ROWSPAN=1>
VEN
</tr>

<tr >

<th class='mathema' scope="row" >
8.00
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/ZAFFANI Stefania.php" class="nodecBlack">ZAFFANI Stefania</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0000FF" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>SCIENZE</p>
<p id = 'nodecWhite'><a href="../Docenti/IACOCCA Barbara.php" class="nodecWhite">IACOCCA Barbara</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
8.50
</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=1 ROWSPAN=2 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/ZAFFANI Stefania.php" class="nodecBlack">ZAFFANI Stefania</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/MORO Margherita.php" class="nodecBlack">MORO Margherita</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/ZAFFANI Stefania.php" class="nodecBlack">ZAFFANI Stefania</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/ZAFFANI Stefania.php" class="nodecBlack">ZAFFANI Stefania</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#00A0A0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE</p>
<p id = 'nodecBlack'><a href="../Docenti/DE GAETANO Maria Carmela.php" class="nodecBlack">DE GAETANO Maria Carmela</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
9.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#00A0A0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE</p>
<p id = 'nodecBlack'><a href="../Docenti/DE GAETANO Maria Carmela.php" class="nodecBlack">DE GAETANO Maria Carmela</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF70FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INFORMATICA</p>
<p id = 'nodecBlack'><a href="../Docenti/OTTAVIANI Maria Grazia.php" class="nodecBlack">OTTAVIANI Maria Grazia</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/MORO Margherita.php" class="nodecBlack">MORO Margherita</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/ZAFFANI Stefania.php" class="nodecBlack">ZAFFANI Stefania</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
10.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#FF70FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INFORMATICA</p>
<p id = 'nodecBlack'><a href="../Docenti/OTTAVIANI Maria Grazia.php" class="nodecBlack">OTTAVIANI Maria Grazia</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA0FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>GEOGRAFIA</p>
<p id = 'nodecBlack'><a href="../Docenti/PEtrONILLI Luciana.php" class="nodecBlack">PEtrONILLI Luciana</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0000FF" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>SCIENZE</p>
<p id = 'nodecWhite'><a href="../Docenti/IACOCCA Barbara.php" class="nodecWhite">IACOCCA Barbara</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA0FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>GEOGRAFIA</p>
<p id = 'nodecBlack'><a href="../Docenti/PEtrONILLI Luciana.php" class="nodecBlack">PEtrONILLI Luciana</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0000FF" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>SCIENZE</p>
<p id = 'nodecWhite'><a href="../Docenti/IACOCCA Barbara.php" class="nodecWhite">IACOCCA Barbara</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
11.30
</td>

<td class = 'nodecWhite'  BGCOLOR="#0000FF" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>SCIENZE</p>
<p id = 'nodecWhite'><a href="../Docenti/IACOCCA Barbara.php" class="nodecWhite">IACOCCA Barbara</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/MARCANTONI Sara.php" class="nodecBlack">MARCANTONI Sara</a> - <a href="../Aule/palestra B.php" class="nodecBlack">palestra B</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/MARCANTONI Sara.php" class="nodecBlack">MARCANTONI Sara</a> - <a href="../Aule/palestra A.php" class="nodecBlack">palestra A</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8040" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO ED ECONOMIA</p>
<p id = 'nodecBlack'><a href="../Docenti/PARISE Simonetta.php" class="nodecBlack">PARISE Simonetta</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA0FF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>GEOGRAFIA</p>
<p id = 'nodecBlack'><a href="../Docenti/PEtrONILLI Luciana.php" class="nodecBlack">PEtrONILLI Luciana</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
12.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/MORO Margherita.php" class="nodecBlack">MORO Margherita</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8040" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO ED ECONOMIA</p>
<p id = 'nodecBlack'><a href="../Docenti/PARISE Simonetta.php" class="nodecBlack">PARISE Simonetta</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#C000C0" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>TEDESCO</p>
<p id = 'nodecWhite'><a href="../Docenti/SORDILLO Edvige.php" class="nodecWhite">SORDILLO Edvige</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/BISCOLA Orietta.php" class="nodecWhite">BISCOLA Orietta</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#C000C0" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>TEDESCO</p>
<p id = 'nodecWhite'><a href="../Docenti/SORDILLO Edvige.php" class="nodecWhite">SORDILLO Edvige</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
13.20
</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/BISCOLA Orietta.php" class="nodecWhite">BISCOLA Orietta</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/BISCOLA Orietta.php" class="nodecWhite">BISCOLA Orietta</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/BISCOLA Orietta.php" class="nodecWhite">BISCOLA Orietta</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
14.20
</td>

<td class = 'nodecWhite'  BGCOLOR="#C000C0" COLSPAN=1 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>TEDESCO</p>
<p id = 'nodecWhite'><a href="../Docenti/SORDILLO Edvige.php" class="nodecWhite">SORDILLO Edvige</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=1 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELIGIONE</p>
<p id = 'nodecBlack'><a href="../Docenti/BARBIERI Angelo.php" class="nodecBlack">BARBIERI Angelo</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=1 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

</table>



        </div>

<?php include '../footer.html';?>
</body>
</html>
