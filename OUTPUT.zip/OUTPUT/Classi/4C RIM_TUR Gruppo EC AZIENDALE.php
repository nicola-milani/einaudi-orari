<html>
    <head>
        <?php include '../href.html';?>
    </head>
    <body>
        <?php include '../header.html';?>
        <div align="center">
<p class='mathema'>
ORARIO CLASSE 4C RIM/TUR Gruppo EC AZIENDALE</p>
</div>
    <div align="center">


<table BORDER=2 WIDTH="90%" CELLSPACING=0 CELLPADDING=4>

<tr >

<td class = 'mathema'>
&nbsp;
</td>

<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
LUN
<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
MAR
<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
MER
<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
GIO
<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
VEN
</tr>

<tr >

<th class='mathema' scope="row" >
8.00
</td>

<td class = 'nodecBlack'  BGCOLOR="#FFC0C0" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>ARTE e TERRITORIO</p>
<p id = 'nodecBlack'><a href="../Docenti/VENDITTI Debora.php" class="nodecBlack">VENDITTI Debora</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C articolata RIM_TUR Gruppo ARTE E TERR.php" class="nodecBlack">4C articolata RIM/TUR Gruppo ARTE E TERR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FF80" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELAZ INTERNAZIONALI</p>
<p id = 'nodecBlack'><a href="../Docenti/PELLIZZARI Stefania.php" class="nodecBlack">PELLIZZARI Stefania</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C articolata RIM_TUR Gruppo RELAZ INTERN.php" class="nodecBlack">4C articolata RIM/TUR Gruppo RELAZ INTERN</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#9000FF" COLSPAN=3 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>INGLESE 1</p>
<p id = 'nodecWhite'><a href="../Docenti/MORO Margherita.php" class="nodecWhite">MORO Margherita</a></p>
<p id = 'nodecWhite'><a href="../Classi/4C RIM_TUR Gruppo INGLESE 1.php" class="nodecWhite">4C RIM/TUR Gruppo INGLESE 1</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/BARES Camilla.php" class="nodecBlack">BARES Camilla</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C RIM_TUR Gruppo INGLESEX.php" class="nodecBlack">4C RIM/TUR Gruppo INGLESEX</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
8.50
</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/BENATI FEZZI Marta.php" class="nodecBlack">BENATI FEZZI Marta</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C RIM_TUR.php" class="nodecBlack">4C RIM/TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/GRIGATO Cesare.php" class="nodecBlack">GRIGATO Cesare</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/BENATI FEZZI Marta.php" class="nodecBlack">BENATI FEZZI Marta</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C RIM_TUR.php" class="nodecBlack">4C RIM/TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/CUESTA Pizarro Guadalupe.php" class="nodecBlack">CUESTA Pizarro Guadalupe</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo SPA 2.php" class="nodecBlack">4A RIM gruppo SPA 2</a> - <a href="../Classi/4C RIM gruppo SPA 2.php" class="nodecBlack">4C RIM gruppo SPA 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#00FF00" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L2</p>
<p id = 'nodecBlack'><a href="../Docenti/SORDILLO Edvige.php" class="nodecBlack">SORDILLO Edvige</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C TUR gruppo TED 2.php" class="nodecBlack">4C TUR gruppo TED 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/CRISTANINI Antonella.php" class="nodecBlack">CRISTANINI Antonella</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C RIM_TUR.php" class="nodecBlack">4C RIM/TUR</a> - <a href="../Aule/palestra A.php" class="nodecBlack">palestra A</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
9.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/GRIGATO Cesare.php" class="nodecBlack">GRIGATO Cesare</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#9000FF" COLSPAN=3 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>INGLESE 1</p>
<p id = 'nodecWhite'><a href="../Docenti/MORO Margherita.php" class="nodecWhite">MORO Margherita</a></p>
<p id = 'nodecWhite'><a href="../Classi/4C RIM_TUR Gruppo INGLESE 1.php" class="nodecWhite">4C RIM/TUR Gruppo INGLESE 1</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/BARES Camilla.php" class="nodecBlack">BARES Camilla</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C RIM_TUR Gruppo INGLESEX.php" class="nodecBlack">4C RIM/TUR Gruppo INGLESEX</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/CUESTA Pizarro Guadalupe.php" class="nodecBlack">CUESTA Pizarro Guadalupe</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo SPA 2.php" class="nodecBlack">4A RIM gruppo SPA 2</a> - <a href="../Classi/4C RIM gruppo SPA 2.php" class="nodecBlack">4C RIM gruppo SPA 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#00FF00" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L2</p>
<p id = 'nodecBlack'><a href="../Docenti/SORDILLO Edvige.php" class="nodecBlack">SORDILLO Edvige</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C TUR gruppo TED 2.php" class="nodecBlack">4C TUR gruppo TED 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0FFC0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>CIN L3</p>
<p id = 'nodecBlack'><a href="../Docenti/PITTORE Maria Nunzia.php" class="nodecBlack">PITTORE Maria Nunzia</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo CIN 3.php" class="nodecBlack">4A RIM gruppo CIN 3</a> - <a href="../Classi/4B RIM gruppo CIN 3.php" class="nodecBlack">4B RIM gruppo CIN 3</a> - <a href="../Classi/4C RIM gruppo CIN 3.php" class="nodecBlack">4C RIM gruppo CIN 3</a> - <a href="../Classi/4E TUR gruppo CIN 3.php" class="nodecBlack">4E TUR gruppo CIN 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA000" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L3</p>
<p id = 'nodecBlack'><a href="../Docenti/MARCONCINI Monica.php" class="nodecBlack">MARCONCINI Monica</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo TED 3.php" class="nodecBlack">4A RIM gruppo TED 3</a> - <a href="../Classi/4B RIM gruppo TED 3.php" class="nodecBlack">4B RIM gruppo TED 3</a> - <a href="../Classi/4C RIM gruppo TED 3.php" class="nodecBlack">4C RIM gruppo TED 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/DI MAIUTA Anna.php" class="nodecBlack">DI MAIUTA Anna</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C TUR gruppo SPA 3.php" class="nodecBlack">4C TUR gruppo SPA 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=2 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/BENATI FEZZI Marta.php" class="nodecBlack">BENATI FEZZI Marta</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C RIM_TUR.php" class="nodecBlack">4C RIM/TUR</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
10.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#C0FFC0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>CIN L3</p>
<p id = 'nodecBlack'><a href="../Docenti/PITTORE Maria Nunzia.php" class="nodecBlack">PITTORE Maria Nunzia</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo CIN 3.php" class="nodecBlack">4A RIM gruppo CIN 3</a> - <a href="../Classi/4B RIM gruppo CIN 3.php" class="nodecBlack">4B RIM gruppo CIN 3</a> - <a href="../Classi/4C RIM gruppo CIN 3.php" class="nodecBlack">4C RIM gruppo CIN 3</a> - <a href="../Classi/4E TUR gruppo CIN 3.php" class="nodecBlack">4E TUR gruppo CIN 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA000" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L3</p>
<p id = 'nodecBlack'><a href="../Docenti/MARCONCINI Monica.php" class="nodecBlack">MARCONCINI Monica</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo TED 3.php" class="nodecBlack">4A RIM gruppo TED 3</a> - <a href="../Classi/4B RIM gruppo TED 3.php" class="nodecBlack">4B RIM gruppo TED 3</a> - <a href="../Classi/4C RIM gruppo TED 3.php" class="nodecBlack">4C RIM gruppo TED 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/DI MAIUTA Anna.php" class="nodecBlack">DI MAIUTA Anna</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C TUR gruppo SPA 3.php" class="nodecBlack">4C TUR gruppo SPA 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFC0C0" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>ARTE e TERRITORIO</p>
<p id = 'nodecBlack'><a href="../Docenti/VENDITTI Debora.php" class="nodecBlack">VENDITTI Debora</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C articolata RIM_TUR Gruppo ARTE E TERR.php" class="nodecBlack">4C articolata RIM/TUR Gruppo ARTE E TERR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FF80" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELAZ INTERNAZIONALI</p>
<p id = 'nodecBlack'><a href="../Docenti/PELLIZZARI Stefania.php" class="nodecBlack">PELLIZZARI Stefania</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C articolata RIM_TUR Gruppo RELAZ INTERN.php" class="nodecBlack">4C articolata RIM/TUR Gruppo RELAZ INTERN</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#D0C0FF" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO e LEG. TUR1</p>
<p id = 'nodecBlack'><a href="../Docenti/SPOSITO Roberto.php" class="nodecBlack">SPOSITO Roberto</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C articolata RIM_TUR Gruppo DIR E LEG TUR.php" class="nodecBlack">4C articolata RIM/TUR Gruppo DIR E LEG TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0E0E0" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO</p>
<p id = 'nodecBlack'><a href="../Docenti/ANGILELLO Andrea.php" class="nodecBlack">ANGILELLO Andrea</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C articolata RIM_TUR Gruppo DIRITTO RIM.php" class="nodecBlack">4C articolata RIM/TUR Gruppo DIRITTO RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELIGIONE</p>
<p id = 'nodecBlack'><a href="../Docenti/LIGORIO Marco.php" class="nodecBlack">LIGORIO Marco</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C RIM_TUR.php" class="nodecBlack">4C RIM/TUR</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
11.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8000" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>GEO TURISTICA</p>
<p id = 'nodecBlack'><a href="../Docenti/BIANCARDI Gabriella.php" class="nodecBlack">BIANCARDI Gabriella</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C articolata RIM_TUR Gruppo GEOGR TUR.php" class="nodecBlack">4C articolata RIM/TUR Gruppo GEOGR TUR</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#FF00FF" COLSPAN=3 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>TEC. COMUNICAZIONI</p>
<p id = 'nodecWhite'><a href="../Docenti/FEDERICO Maria.php" class="nodecWhite">FEDERICO Maria</a></p>
<p id = 'nodecWhite'><a href="../Classi/4C articolata RIM_TUR Gruppo TEC COM.php" class="nodecWhite">4C articolata RIM/TUR Gruppo TEC COM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/CUESTA Pizarro Guadalupe.php" class="nodecBlack">CUESTA Pizarro Guadalupe</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo SPA 2.php" class="nodecBlack">4A RIM gruppo SPA 2</a> - <a href="../Classi/4C RIM gruppo SPA 2.php" class="nodecBlack">4C RIM gruppo SPA 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#00FF00" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L2</p>
<p id = 'nodecBlack'><a href="../Docenti/SORDILLO Edvige.php" class="nodecBlack">SORDILLO Edvige</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C TUR gruppo TED 2.php" class="nodecBlack">4C TUR gruppo TED 2</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/GRIGATO Cesare.php" class="nodecBlack">GRIGATO Cesare</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/BENATI FEZZI Marta.php" class="nodecBlack">BENATI FEZZI Marta</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C RIM_TUR.php" class="nodecBlack">4C RIM/TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#D0C0FF" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO e LEG. TUR1</p>
<p id = 'nodecBlack'><a href="../Docenti/SPOSITO Roberto.php" class="nodecBlack">SPOSITO Roberto</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C articolata RIM_TUR Gruppo DIRITTO e LEG TUR1.php" class="nodecBlack">4C articolata RIM/TUR Gruppo DIRITTO e LEG TUR1</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#FF0000" COLSPAN=3 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>EC. AZIENDALE e GEO POL.1</p>
<p id = 'nodecWhite'><a href="../Docenti/GRIGATO Cesare.php" class="nodecWhite">GRIGATO Cesare</a></p>
<p id = 'nodecWhite'><a href="../Classi/4C articolata RIM_TUR Gruppo EC AZ e GEOPOL1.php" class="nodecWhite">4C articolata RIM/TUR Gruppo EC AZ e GEOPOL1</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
12.30
</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/CARUSO Maria.php" class="nodecWhite">CARUSO Maria</a></p>
<p id = 'nodecWhite'><a href="../Classi/4C RIM_TUR.php" class="nodecWhite">4C RIM/TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#D0C0FF" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO e LEG. TUR1</p>
<p id = 'nodecBlack'><a href="../Docenti/SPOSITO Roberto.php" class="nodecBlack">SPOSITO Roberto</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C articolata RIM_TUR Gruppo DIR E LEG TUR.php" class="nodecBlack">4C articolata RIM/TUR Gruppo DIR E LEG TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0E0E0" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO</p>
<p id = 'nodecBlack'><a href="../Docenti/ANGILELLO Andrea.php" class="nodecBlack">ANGILELLO Andrea</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C articolata RIM_TUR Gruppo DIRITTO RIM.php" class="nodecBlack">4C articolata RIM/TUR Gruppo DIRITTO RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/CRISTANINI Antonella.php" class="nodecBlack">CRISTANINI Antonella</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C RIM_TUR.php" class="nodecBlack">4C RIM/TUR</a> - <a href="../Aule/palestra B.php" class="nodecBlack">palestra B</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/GRIGATO Cesare.php" class="nodecBlack">GRIGATO Cesare</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0FFC0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>CIN L3</p>
<p id = 'nodecBlack'><a href="../Docenti/PITTORE Maria Nunzia.php" class="nodecBlack">PITTORE Maria Nunzia</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo CIN 3.php" class="nodecBlack">4A RIM gruppo CIN 3</a> - <a href="../Classi/4B RIM gruppo CIN 3.php" class="nodecBlack">4B RIM gruppo CIN 3</a> - <a href="../Classi/4C RIM gruppo CIN 3.php" class="nodecBlack">4C RIM gruppo CIN 3</a> - <a href="../Classi/4E TUR gruppo CIN 3.php" class="nodecBlack">4E TUR gruppo CIN 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA000" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L3</p>
<p id = 'nodecBlack'><a href="../Docenti/MARCONCINI Monica.php" class="nodecBlack">MARCONCINI Monica</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo TED 3.php" class="nodecBlack">4A RIM gruppo TED 3</a> - <a href="../Classi/4B RIM gruppo TED 3.php" class="nodecBlack">4B RIM gruppo TED 3</a> - <a href="../Classi/4C RIM gruppo TED 3.php" class="nodecBlack">4C RIM gruppo TED 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/DI MAIUTA Anna.php" class="nodecBlack">DI MAIUTA Anna</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C TUR gruppo SPA 3.php" class="nodecBlack">4C TUR gruppo SPA 3</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
13.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/BENATI FEZZI Marta.php" class="nodecBlack">BENATI FEZZI Marta</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C RIM_TUR.php" class="nodecBlack">4C RIM/TUR</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/CARUSO Maria.php" class="nodecWhite">CARUSO Maria</a></p>
<p id = 'nodecWhite'><a href="../Classi/4C RIM_TUR.php" class="nodecWhite">4C RIM/TUR</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8000" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>GEO TURISTICA</p>
<p id = 'nodecBlack'><a href="../Docenti/BIANCARDI Gabriella.php" class="nodecBlack">BIANCARDI Gabriella</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C articolata RIM_TUR Gruppo GEOGR TUR.php" class="nodecBlack">4C articolata RIM/TUR Gruppo GEOGR TUR</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#FF00FF" COLSPAN=3 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>TEC. COMUNICAZIONI</p>
<p id = 'nodecWhite'><a href="../Docenti/FEDERICO Maria.php" class="nodecWhite">FEDERICO Maria</a></p>
<p id = 'nodecWhite'><a href="../Classi/4C articolata RIM_TUR Gruppo TEC COM.php" class="nodecWhite">4C articolata RIM/TUR Gruppo TEC COM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
14.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#9000FF" COLSPAN=3 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>INGLESE 1</p>
<p id = 'nodecWhite'><a href="../Docenti/MORO Margherita.php" class="nodecWhite">MORO Margherita</a></p>
<p id = 'nodecWhite'><a href="../Classi/4C RIM_TUR Gruppo INGLESE 1.php" class="nodecWhite">4C RIM/TUR Gruppo INGLESE 1</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=3 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/BARES Camilla.php" class="nodecBlack">BARES Camilla</a></p>
<p id = 'nodecBlack'><a href="../Classi/4C RIM_TUR Gruppo INGLESEX.php" class="nodecBlack">4C RIM/TUR Gruppo INGLESEX</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/CARUSO Maria.php" class="nodecWhite">CARUSO Maria</a></p>
<p id = 'nodecWhite'><a href="../Classi/4C RIM_TUR.php" class="nodecWhite">4C RIM/TUR</a></p>

</td>

</tr>

</table>



        </div>

<?php include '../footer.html';?>
</body>
</html>
