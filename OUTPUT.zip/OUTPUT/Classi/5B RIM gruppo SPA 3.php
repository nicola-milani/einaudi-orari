<html>
    <head>
        <?php include '../href.html';?>
    </head>
    <body>
        <?php include '../header.html';?>
        <div align="center">
<p class='mathema'>
ORARIO CLASSE 5B RIM gruppo SPA 3</p>
</div>
    <div align="center">


<table BORDER=2 WIDTH="90%" CELLSPACING=0 CELLPADDING=4>

<tr >

<td class = 'mathema'>
&nbsp;
</td>

<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
LUN
<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
MAR
<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
MER
<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
GIO
<td class = 'mathema'   COLSPAN=2 ROWSPAN=1>
VEN
</tr>

<tr >

<th class='mathema' scope="row" >
8.00
</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>FRA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/FULLY Veronique.php" class="nodecBlack">FULLY Veronique</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FF80" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELAZ INTERNAZIONALI</p>
<p id = 'nodecBlack'><a href="../Docenti/OTTAVIANO Clara.php" class="nodecBlack">OTTAVIANO Clara</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/LANZAROTTO Antonio.php" class="nodecBlack">LANZAROTTO Antonio</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/CAVALLINI Egidio.php" class="nodecBlack">CAVALLINI Egidio</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a> - <a href="../Aule/palestra A.php" class="nodecBlack">palestra A</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
8.50
</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/PIEtrAFESA Giovanna.php" class="nodecWhite">PIEtrAFESA Giovanna</a></p>
<p id = 'nodecWhite'><a href="../Classi/5B RIM.php" class="nodecWhite">5B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/DI PLACIDO Giuseppina.php" class="nodecBlack">DI PLACIDO Giuseppina</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/DI MAIUTA Anna.php" class="nodecBlack">DI MAIUTA Anna</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/LANZAROTTO Antonio.php" class="nodecBlack">LANZAROTTO Antonio</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/FACCI Lorenzo.php" class="nodecBlack">FACCI Lorenzo</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
9.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#C0E0E0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO</p>
<p id = 'nodecBlack'><a href="../Docenti/LO CIStrO Guido.php" class="nodecBlack">LO CIStrO Guido</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/DI MAIUTA Anna.php" class="nodecBlack">DI MAIUTA Anna</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/FACCI Lorenzo.php" class="nodecBlack">FACCI Lorenzo</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FF80" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELAZ INTERNAZIONALI</p>
<p id = 'nodecBlack'><a href="../Docenti/OTTAVIANO Clara.php" class="nodecBlack">OTTAVIANO Clara</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A0FFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/DI MAIUTA Anna.php" class="nodecBlack">DI MAIUTA Anna</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
10.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/DI PLACIDO Giuseppina.php" class="nodecBlack">DI PLACIDO Giuseppina</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>FRA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/FULLY Veronique.php" class="nodecBlack">FULLY Veronique</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0E0E0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO</p>
<p id = 'nodecBlack'><a href="../Docenti/LO CIStrO Guido.php" class="nodecBlack">LO CIStrO Guido</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0C000" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>FRA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/FULLY Veronique.php" class="nodecBlack">FULLY Veronique</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/LANZAROTTO Antonio.php" class="nodecBlack">LANZAROTTO Antonio</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
11.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/LANZAROTTO Antonio.php" class="nodecBlack">LANZAROTTO Antonio</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#B0B0FF" COLSPAN=2 ROWSPAN=2 COLOR="#000000">
<p id = 'nodecBlack'>EC. AZIENDALE e GEO POL.</p>
<p id = 'nodecBlack'><a href="../Docenti/LANZAROTTO Antonio.php" class="nodecBlack">LANZAROTTO Antonio</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELIGIONE</p>
<p id = 'nodecBlack'><a href="../Docenti/BARBIERI Angelo.php" class="nodecBlack">BARBIERI Angelo</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/CAVALLINI Egidio.php" class="nodecBlack">CAVALLINI Egidio</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a> - <a href="../Aule/palestra B.php" class="nodecBlack">palestra B</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/DI PLACIDO Giuseppina.php" class="nodecBlack">DI PLACIDO Giuseppina</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
12.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/FACCI Lorenzo.php" class="nodecBlack">FACCI Lorenzo</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FF80" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELAZ INTERNAZIONALI</p>
<p id = 'nodecBlack'><a href="../Docenti/OTTAVIANO Clara.php" class="nodecBlack">OTTAVIANO Clara</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/PIEtrAFESA Giovanna.php" class="nodecWhite">PIEtrAFESA Giovanna</a></p>
<p id = 'nodecWhite'><a href="../Classi/5B RIM.php" class="nodecWhite">5B RIM</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=2 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/PIEtrAFESA Giovanna.php" class="nodecWhite">PIEtrAFESA Giovanna</a></p>
<p id = 'nodecWhite'><a href="../Classi/5B RIM.php" class="nodecWhite">5B RIM</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
13.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/FACCI Lorenzo.php" class="nodecBlack">FACCI Lorenzo</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=2 ROWSPAN=2 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/FACCI Lorenzo.php" class="nodecBlack">FACCI Lorenzo</a></p>
<p id = 'nodecBlack'><a href="../Classi/5B RIM.php" class="nodecBlack">5B RIM</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
14.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

</table>



        </div>

<?php include '../footer.html';?>
</body>
</html>
