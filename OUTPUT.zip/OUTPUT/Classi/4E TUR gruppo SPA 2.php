<html>
    <head>
        <?php include '../href.html';?>
    </head>
    <body>
        <?php include '../header.html';?>
        <div align="center">
<p class='mathema'>
ORARIO CLASSE 4E TUR gruppo SPA 2</p>
</div>
    <div align="center">


<table BORDER=2 WIDTH="90%" CELLSPACING=0 CELLPADDING=4>

<tr >

<td class = 'mathema'>
&nbsp;
</td>

<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
LUN
<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
MAR
<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
MER
<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
GIO
<td class = 'mathema'   COLSPAN=6 ROWSPAN=1>
VEN
</tr>

<tr >

<th class='mathema' scope="row" >
8.00
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#FF4040" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>DTA</p>
<p id = 'nodecWhite'><a href="../Docenti/SPATARO Roberta Virginia.php" class="nodecWhite">SPATARO Roberta Virginia</a></p>
<p id = 'nodecWhite'><a href="../Classi/4E TUR.php" class="nodecWhite">4E TUR</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFC0C0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>ARTE e TERRITORIO</p>
<p id = 'nodecBlack'><a href="../Docenti/VENDITTI Debora.php" class="nodecBlack">VENDITTI Debora</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
8.50
</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/MARCANTONI Sara.php" class="nodecBlack">MARCANTONI Sara</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a> - <a href="../Aule/palestra B.php" class="nodecBlack">palestra B</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8000" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>GEO TURISTICA</p>
<p id = 'nodecBlack'><a href="../Docenti/BIANCARDI Gabriella.php" class="nodecBlack">BIANCARDI Gabriella</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/MOI Elisa.php" class="nodecBlack">MOI Elisa</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/BERNI Rossana.php" class="nodecWhite">BERNI Rossana</a></p>
<p id = 'nodecWhite'><a href="../Classi/4E TUR.php" class="nodecWhite">4E TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/DI PLACIDO Giuseppina.php" class="nodecBlack">DI PLACIDO Giuseppina</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
9.40
</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/BERNI Rossana.php" class="nodecWhite">BERNI Rossana</a></p>
<p id = 'nodecWhite'><a href="../Classi/4E TUR.php" class="nodecWhite">4E TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=2 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/MOI Elisa.php" class="nodecBlack">MOI Elisa</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#D0C0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO e LEG. TUR1</p>
<p id = 'nodecBlack'><a href="../Docenti/LO CIStrO Guido.php" class="nodecBlack">LO CIStrO Guido</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0FFC0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>CIN L3</p>
<p id = 'nodecBlack'><a href="../Docenti/PITTORE Maria Nunzia.php" class="nodecBlack">PITTORE Maria Nunzia</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo CIN 3.php" class="nodecBlack">4A RIM gruppo CIN 3</a> - <a href="../Classi/4B RIM gruppo CIN 3.php" class="nodecBlack">4B RIM gruppo CIN 3</a> - <a href="../Classi/4C RIM gruppo CIN 3.php" class="nodecBlack">4C RIM gruppo CIN 3</a> - <a href="../Classi/4E TUR gruppo CIN 3.php" class="nodecBlack">4E TUR gruppo CIN 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#8080FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>FRA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/CADDEO Rita Paola.php" class="nodecBlack">CADDEO Rita Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR gruppo FRA 3.php" class="nodecBlack">4E TUR gruppo FRA 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA000" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L3</p>
<p id = 'nodecBlack'><a href="../Docenti/BONELLI Paola.php" class="nodecBlack">BONELLI Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo TED 3.php" class="nodecBlack">4D TUR gruppo TED 3</a> - <a href="../Classi/4E TUR gruppo TED 3.php" class="nodecBlack">4E TUR gruppo TED 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/DE CARO Sofia.php" class="nodecBlack">DE CARO Sofia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
10.40
</td>

<td class = 'nodecBlack'  BGCOLOR="#C0FFC0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>CIN L3</p>
<p id = 'nodecBlack'><a href="../Docenti/PITTORE Maria Nunzia.php" class="nodecBlack">PITTORE Maria Nunzia</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo CIN 3.php" class="nodecBlack">4A RIM gruppo CIN 3</a> - <a href="../Classi/4B RIM gruppo CIN 3.php" class="nodecBlack">4B RIM gruppo CIN 3</a> - <a href="../Classi/4C RIM gruppo CIN 3.php" class="nodecBlack">4C RIM gruppo CIN 3</a> - <a href="../Classi/4E TUR gruppo CIN 3.php" class="nodecBlack">4E TUR gruppo CIN 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#8080FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>FRA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/CADDEO Rita Paola.php" class="nodecBlack">CADDEO Rita Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR gruppo FRA 3.php" class="nodecBlack">4E TUR gruppo FRA 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA000" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L3</p>
<p id = 'nodecBlack'><a href="../Docenti/BONELLI Paola.php" class="nodecBlack">BONELLI Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo TED 3.php" class="nodecBlack">4D TUR gruppo TED 3</a> - <a href="../Classi/4E TUR gruppo TED 3.php" class="nodecBlack">4E TUR gruppo TED 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/MOI Elisa.php" class="nodecBlack">MOI Elisa</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#D0C0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO e LEG. TUR1</p>
<p id = 'nodecBlack'><a href="../Docenti/LO CIStrO Guido.php" class="nodecBlack">LO CIStrO Guido</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#FF4040" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>DTA</p>
<p id = 'nodecWhite'><a href="../Docenti/SPATARO Roberta Virginia.php" class="nodecWhite">SPATARO Roberta Virginia</a></p>
<p id = 'nodecWhite'><a href="../Classi/4E TUR.php" class="nodecWhite">4E TUR</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
11.30
</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/DE CARO Sofia.php" class="nodecBlack">DE CARO Sofia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/DI PLACIDO Giuseppina.php" class="nodecBlack">DI PLACIDO Giuseppina</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a></p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#0080E0" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>MATEMATICA</p>
<p id = 'nodecWhite'><a href="../Docenti/BERNI Rossana.php" class="nodecWhite">BERNI Rossana</a></p>
<p id = 'nodecWhite'><a href="../Classi/4E TUR.php" class="nodecWhite">4E TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#80FFFF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>INGLESE</p>
<p id = 'nodecBlack'><a href="../Docenti/DI PLACIDO Giuseppina.php" class="nodecBlack">DI PLACIDO Giuseppina</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/MOI Elisa.php" class="nodecBlack">MOI Elisa</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
12.30
</td>

<td class = 'nodecWhite'  BGCOLOR="#FF4040" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>DTA</p>
<p id = 'nodecWhite'><a href="../Docenti/SPATARO Roberta Virginia.php" class="nodecWhite">SPATARO Roberta Virginia</a></p>
<p id = 'nodecWhite'><a href="../Classi/4E TUR.php" class="nodecWhite">4E TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#D0C0FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>DIRITTO e LEG. TUR1</p>
<p id = 'nodecBlack'><a href="../Docenti/LO CIStrO Guido.php" class="nodecBlack">LO CIStrO Guido</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFC0C0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>ARTE e TERRITORIO</p>
<p id = 'nodecBlack'><a href="../Docenti/VENDITTI Debora.php" class="nodecBlack">VENDITTI Debora</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFF00" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SPA L2</p>
<p id = 'nodecBlack'><a href="../Docenti/DE CARO Sofia.php" class="nodecBlack">DE CARO Sofia</a></p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#C0FFC0" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>CIN L3</p>
<p id = 'nodecBlack'><a href="../Docenti/PITTORE Maria Nunzia.php" class="nodecBlack">PITTORE Maria Nunzia</a></p>
<p id = 'nodecBlack'><a href="../Classi/4A RIM gruppo CIN 3.php" class="nodecBlack">4A RIM gruppo CIN 3</a> - <a href="../Classi/4B RIM gruppo CIN 3.php" class="nodecBlack">4B RIM gruppo CIN 3</a> - <a href="../Classi/4C RIM gruppo CIN 3.php" class="nodecBlack">4C RIM gruppo CIN 3</a> - <a href="../Classi/4E TUR gruppo CIN 3.php" class="nodecBlack">4E TUR gruppo CIN 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#8080FF" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>FRA L3</p>
<p id = 'nodecBlack'><a href="../Docenti/CADDEO Rita Paola.php" class="nodecBlack">CADDEO Rita Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR gruppo FRA 3.php" class="nodecBlack">4E TUR gruppo FRA 3</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FFA000" COLSPAN=2 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>TED L3</p>
<p id = 'nodecBlack'><a href="../Docenti/BONELLI Paola.php" class="nodecBlack">BONELLI Paola</a></p>
<p id = 'nodecBlack'><a href="../Classi/4D TUR gruppo TED 3.php" class="nodecBlack">4D TUR gruppo TED 3</a> - <a href="../Classi/4E TUR gruppo TED 3.php" class="nodecBlack">4E TUR gruppo TED 3</a></p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
13.20
</td>

<td class = 'nodecBlack'  BGCOLOR="#FFFFA0" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>LETTERE</p>
<p id = 'nodecBlack'><a href="../Docenti/MOI Elisa.php" class="nodecBlack">MOI Elisa</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a></p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8080" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>RELIGIONE</p>
<p id = 'nodecBlack'><a href="../Docenti/LIGORIO Marco.php" class="nodecBlack">LIGORIO Marco</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#FF8000" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>GEO TURISTICA</p>
<p id = 'nodecBlack'><a href="../Docenti/BIANCARDI Gabriella.php" class="nodecBlack">BIANCARDI Gabriella</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

<tr >

<th class='mathema' scope="row" >
14.20
</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecBlack'  BGCOLOR="#A090FF" COLSPAN=6 ROWSPAN=1 COLOR="#000000">
<p id = 'nodecBlack'>SCIENZE MOTORIE</p>
<p id = 'nodecBlack'><a href="../Docenti/MARCANTONI Sara.php" class="nodecBlack">MARCANTONI Sara</a></p>
<p id = 'nodecBlack'><a href="../Classi/4E TUR.php" class="nodecBlack">4E TUR</a> - <a href="../Aule/palestra A.php" class="nodecBlack">palestra A</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=6 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'nodecWhite'  BGCOLOR="#FF4040" COLSPAN=6 ROWSPAN=1 COLOR="#FFFFFF">
<p id = 'nodecWhite'>DTA</p>
<p id = 'nodecWhite'><a href="../Docenti/SPATARO Roberta Virginia.php" class="nodecWhite">SPATARO Roberta Virginia</a></p>
<p id = 'nodecWhite'><a href="../Classi/4E TUR.php" class="nodecWhite">4E TUR</a></p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

<td class = 'mathema'  BGCOLOR="#FFFFFF"  COLSPAN=2 ROWSPAN=1>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>
<p id = 'mathema'>&nbsp;<p>

</td>

</tr>

</table>



        </div>

<?php include '../footer.html';?>
</body>
</html>
