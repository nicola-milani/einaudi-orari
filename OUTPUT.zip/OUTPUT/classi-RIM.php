<HTML>

<HEAD>
    <?php include 'href.html';?>
</HEAD>

<BODY>
    <div class='header'>
        <?php include 'header.html';?>
    </div>

    <div align="center">
        <div class="responsive" style="vertical-align: top;">
            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 class="tabel launch">

                <TR VALIGN=TOP>

                    <Th ALIGN=TOP class='mathema'>
                        <b>CLASSI TERZE RIM</b>
                    </Th>
                </tr>
                <tr><td><A HREF="Classi/3A RIM.php" class = 'mathema'>3A RIM</A><BR></td></tr>
                <tr><td><A HREF="Classi/3B RIM.php" class = 'mathema'>3B RIM</A><BR></td></tr>
                <tr><td><A HREF="Classi/3C RIM.php" class = 'mathema'>3C RIM</A><BR></td></tr>
                <tr><td><A HREF="Classi/3D RIM.php" class = 'mathema'>3D RIM</A><BR></td></tr>
                <tr><td><A HREF="Classi/3E RIM.php" class = 'mathema'>3E RIM</A><BR></td></tr>
<!--                 <tr>
                    <td class='mathema'>
                      <p> &nbsp</p>
                    </td>
                </tr>
                <tr>
                    <td class='mathema'>
                    </td>
                </tr> -->
            </TABLE>
        </div>
        <div class="responsive" style="vertical-align: top;">

            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 class="tabel launch">

                <TR VALIGN=TOP>

                    <Th ALIGN=TOP class='mathema'>
                        <b>CLASSI QUARTE RIM</b>
                    </Th>
                </tr>
                <tr><td><A HREF="Classi/4A RIM.php" class = 'mathema'>4A RIM</A><BR></td></tr>
                <tr><td><A HREF="Classi/4B RIM.php" class = 'mathema'>4B RIM</A><BR></td></tr>
                <tr><td><A HREF="Classi/4C RIM_TUR.php" class = 'mathema'>4C RIM/TUR</A><BR></td></tr>
<!--                 <tr>
                    <td class='mathema'>
                      <p> &nbsp</p>
                    </td>
                </tr> -->

            </TABLE>
        </div>
        <div class="responsive" style="vertical-align: top;">

            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 class="tabel launch">

                <TR VALIGN=TOP>

                    <Th ALIGN=TOP class='mathema'>
                        <b>CLASSI QUINTE RIM</b>
                    </Th>
                </tr>
                <tr><td><A HREF="Classi/5A RIM.php" class = 'mathema'>5A RIM</A><BR></td></tr>
                <tr><td><A HREF="Classi/5B RIM.php" class = 'mathema'>5B RIM</A><BR></td></tr>
                <tr><td><A HREF="Classi/5C RIM.php" class = 'mathema'>5C RIM</A><BR></td></tr>
                <tr><td><A HREF="Classi/5D RIM.php" class = 'mathema'>5D RIM</A><BR></td></tr>
<!--                 <tr>
                    <td class='mathema'>
                    </td>
                </tr>
                <tr>
                    <td class='mathema'>
                    </td>
                </tr> -->
            </TABLE>

        </div>
    </div>

    <?php include 'footer.html';?>


</BODY>

</HTML>