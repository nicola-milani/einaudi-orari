<HTML>

<HEAD> 
    <?php include 'href.html';?>
</HEAD>

<BODY>

<div class='header'>
        <?php include 'header.html';?>
    </div>
    <div align="center">
        <div class="responsive">
            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4>

                <TR VALIGN=TOP>

                    <Th ALIGN=TOP class='mathema'>
                        <b>AULE</b>
                    </Th>
                </tr>
                        <tr><td><A HREF="Aule/LABORATORIO CHIMICA.php" class='mathema'>LABORATORIO CHIMICA</A><BR></td></tr>
                        <tr><td><A HREF="Aule/PALESTRA 1.php" class='mathema'>PALESTRA 1</A><BR></td></tr>
                        <tr><td><A HREF="Aule/PALESTRA 2.php" class='mathema'>PALESTRA 2</A><BR></td></tr>
        </TABLE>
    </div>
    </div>

    <?php include 'footer.html';?>
   
</BODY>

</HTML>