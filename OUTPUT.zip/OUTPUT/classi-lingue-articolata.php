<HTML>

<HEAD>
    <?php include 'href.html';?>
</HEAD>

<BODY>
<div class='header'>
        <?php include 'header.html';?>
    </div>
    <div align="center">
    <div class="responsive" style="vertical-align: top;">
        <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4>

            <TR VALIGN=TOP>

                <Th ALIGN=TOP class='mathema'>
                    <b>CLASSI TERZE</b>
                </Th>
            </tr>
<tr><td><A HREF="Classi/3A RIM gruppo FRA L3.php" class = 'mathema'>3A RIM gruppo FRA L3</A><BR></td></tr>
<tr><td><A HREF="Classi/3A RIM gruppo SPA 3.php" class = 'mathema'>3A RIM gruppo SPA 3</A><BR></td></tr>
<tr><td><A HREF="Classi/3B RIM gruppo CIN 3.php" class = 'mathema'>3B RIM gruppo CIN 3</A><BR></td></tr>
<tr><td><A HREF="Classi/3B RIM gruppo SPA 3.php" class = 'mathema'>3B RIM gruppo SPA 3</A><BR></td></tr>
<tr><td><A HREF="Classi/3C RIM gruppo FRA 3.php" class = 'mathema'>3C RIM gruppo FRA 3</A><BR></td></tr>
<tr><td><A HREF="Classi/3C RIM gruppo TED 3.php" class = 'mathema'>3C RIM gruppo TED 3</A><BR></td></tr>
<tr><td><A HREF="Classi/3D RIM gruppo FRA 3.php" class = 'mathema'>3D RIM gruppo FRA 3</A><BR></td></tr>
<tr><td><A HREF="Classi/3D RIM gruppo TED 3.php" class = 'mathema'>3D RIM gruppo TED 3</A><BR></td></tr>
<tr><td><A HREF="Classi/3E RIM gruppo FRA 2.php" class = 'mathema'>3E RIM gruppo FRA 2</A><BR></td></tr>
<tr><td><A HREF="Classi/3E RIM gruppo SPA 2.php" class = 'mathema'>3E RIM gruppo SPA 2</A><BR></td></tr>
<tr><td><A HREF="Classi/3E RIM gruppo CIN 3.php" class = 'mathema'>3E RIM gruppo CIN 3</A><BR></td></tr>
<tr><td><A HREF="Classi/3E RIM gruppo SPA 3.php" class = 'mathema'>3E RIM gruppo SPA 3</A><BR></td></tr>
<tr><td><A HREF="Classi/3F TUR gruppo FRA 2.php" class = 'mathema'>3F TUR gruppo FRA 2</A><BR></td></tr>
<tr><td><A HREF="Classi/3F TUR gruppo SPA 2.php" class = 'mathema'>3F TUR gruppo SPA 2</A><BR></td></tr>
<tr><td><A HREF="Classi/3F TUR gruppo SPA 3.php" class = 'mathema'>3F TUR gruppo SPA 3</A><BR></td></tr>
<tr><td><A HREF="Classi/3F TUR gruppo TED 3.php" class = 'mathema'>3F TUR gruppo TED 3</A><BR></td></tr>
<tr><td><A HREF="Classi/3G TUR gruppo SPA 2.php" class = 'mathema'>3G TUR gruppo SPA 2</A><BR></td></tr>
<tr><td><A HREF="Classi/3G TUR gruppo TED 2.php" class = 'mathema'>3G TUR gruppo TED 2</A><BR></td></tr>
<tr><td><A HREF="Classi/3G TUR gruppo FRA 3.php" class = 'mathema'>3G TUR gruppo FRA 3</A><BR></td></tr>
<tr><td><A HREF="Classi/3G TUR gruppo SPA 3.php" class = 'mathema'>3G TUR gruppo SPA 3</A><BR></td></tr>


        </TABLE>
        </div>
        <div class="responsive" style="vertical-align: top;">
        
        <TABLE BORDER=0  CELLSPACING=0 CELLPADDING=4>

            <TR VALIGN=TOP>

                <Th ALIGN=TOP class='mathema'>
                    <b>CLASSI QUARTE</b>
                </Th>
            </tr>
            <tr><td><A HREF="Classi/4A RIM gruppo SPA 2.php" class = 'mathema'>4A RIM gruppo SPA 2</A><BR></td></tr>
<tr><td><A HREF="Classi/4A RIM gruppo TED 2.php" class = 'mathema'>4A RIM gruppo TED 2</A><BR></td></tr>
<tr><td><A HREF="Classi/4A RIM gruppo CIN 3.php" class = 'mathema'>4A RIM gruppo CIN 3</A><BR></td></tr>
<tr><td><A HREF="Classi/4A RIM gruppo SPA 3.php" class = 'mathema'>4A RIM gruppo SPA 3</A><BR></td></tr>
<tr><td><A HREF="Classi/4A RIM gruppo TED 3.php" class = 'mathema'>4A RIM gruppo TED 3</A><BR></td></tr>
<tr><td><A HREF="Classi/4B RIM gruppo FRA 2.php" class = 'mathema'>4B RIM gruppo FRA 2</A><BR></td></tr>
<tr><td><A HREF="Classi/4B RIM gruppo TED 2.php" class = 'mathema'>4B RIM gruppo TED 2</A><BR></td></tr>
<tr><td><A HREF="Classi/4B RIM gruppo CIN 3.php" class = 'mathema'>4B RIM gruppo CIN 3</A><BR></td></tr>
<tr><td><A HREF="Classi/4B RIM gruppo SPA 3.php" class = 'mathema'>4B RIM gruppo SPA 3</A><BR></td></tr>
<tr><td><A HREF="Classi/4B RIM gruppo TED 3.php" class = 'mathema'>4B RIM gruppo TED 3</A><BR></td></tr>
<tr><td><A HREF="Classi/4C articolata RIM_TUR Gruppo ARTE E TERR.php" class = 'mathema'>4C articolata RIM/TUR Gruppo ARTE E TERR</A><BR></td></tr>
<tr><td><A HREF="Classi/4C articolata RIM_TUR Gruppo RELAZ INTERN.php" class = 'mathema'>4C articolata RIM/TUR Gruppo RELAZ INTERN</A><BR></td></tr>
<tr><td><A HREF="Classi/4C articolata RIM_TUR Gruppo DIR E LEG TUR.php" class = 'mathema'>4C articolata RIM/TUR Gruppo DIR E LEG TUR</A><BR></td></tr>
<tr><td><A HREF="Classi/4C articolata RIM_TUR Gruppo DIRITTO RIM.php" class = 'mathema'>4C articolata RIM/TUR Gruppo DIRITTO RIM</A><BR></td></tr>
<tr><td><A HREF="Classi/4C RIM_TUR Gruppo DTA.php" class = 'mathema'>4C RIM/TUR Gruppo DTA</A><BR></td></tr>
<tr><td><A HREF="Classi/4C RIM_TUR Gruppo EC AZIENDALE.php" class = 'mathema'>4C RIM/TUR Gruppo EC AZIENDALE</A><BR></td></tr>
<tr><td><A HREF="Classi/4C articolata RIM_TUR Gruppo DIRITTO e LEG TUR1.php" class = 'mathema'>4C articolata RIM/TUR Gruppo DIRITTO e LEG TUR1</A><BR></td></tr>
<tr><td><A HREF="Classi/4C articolata RIM_TUR Gruppo EC AZ e GEOPOL1.php" class = 'mathema'>4C articolata RIM/TUR Gruppo EC AZ e GEOPOL1</A><BR></td></tr>
<tr><td><A HREF="Classi/4C RIM_TUR Gruppo INGLESE 1.php" class = 'mathema'>4C RIM/TUR Gruppo INGLESE 1</A><BR></td></tr>
<tr><td><A HREF="Classi/4C RIM_TUR Gruppo INGLESEX.php" class = 'mathema'>4C RIM/TUR Gruppo INGLESEX</A><BR></td></tr>
<tr><td><A HREF="Classi/4C RIM gruppo SPA 2.php" class = 'mathema'>4C RIM gruppo SPA 2</A><BR></td></tr>
<tr><td><A HREF="Classi/4C TUR gruppo TED 2.php" class = 'mathema'>4C TUR gruppo TED 2</A><BR></td></tr>
<tr><td><A HREF="Classi/4C RIM gruppo CIN 3.php" class = 'mathema'>4C RIM gruppo CIN 3</A><BR></td></tr>
<tr><td><A HREF="Classi/4C RIM gruppo TED 3.php" class = 'mathema'>4C RIM gruppo TED 3</A><BR></td></tr>
<tr><td><A HREF="Classi/4C TUR gruppo SPA 3.php" class = 'mathema'>4C TUR gruppo SPA 3</A><BR></td></tr>
<tr><td><A HREF="Classi/4C articolata RIM_TUR Gruppo GEOGR TUR.php" class = 'mathema'>4C articolata RIM/TUR Gruppo GEOGR TUR</A><BR></td></tr>
<tr><td><A HREF="Classi/4C articolata RIM_TUR Gruppo TEC COM.php" class = 'mathema'>4C articolata RIM/TUR Gruppo TEC COM</A><BR></td></tr>
<tr><td><A HREF="Classi/4D TUR gruppo FRA 2.php" class = 'mathema'>4D TUR gruppo FRA 2</A><BR></td></tr>
<tr><td><A HREF="Classi/4D TUR gruppo TED 2.php" class = 'mathema'>4D TUR gruppo TED 2</A><BR></td></tr>
<tr><td><A HREF="Classi/4D TUR gruppo SPA 3.php" class = 'mathema'>4D TUR gruppo SPA 3</A><BR></td></tr>
<tr><td><A HREF="Classi/4D TUR gruppo TED 3.php" class = 'mathema'>4D TUR gruppo TED 3</A><BR></td></tr>
<tr><td><A HREF="Classi/4E TUR gruppo SPA 2.php" class = 'mathema'>4E TUR gruppo SPA 2</A><BR></td></tr>
<tr><td><A HREF="Classi/4E TUR gruppo TED 2.php" class = 'mathema'>4E TUR gruppo TED 2</A><BR></td></tr>
<tr><td><A HREF="Classi/4E TUR gruppo CIN 3.php" class = 'mathema'>4E TUR gruppo CIN 3</A><BR></td></tr>
<tr><td><A HREF="Classi/4E TUR gruppo FRA 3.php" class = 'mathema'>4E TUR gruppo FRA 3</A><BR></td></tr>
<tr><td><A HREF="Classi/4E TUR gruppo TED 3.php" class = 'mathema'>4E TUR gruppo TED 3</A><BR></td></tr>


        </TABLE>
        </div>
        <div class="responsive" style="vertical-align: top;">

        <TABLE BORDER=0  CELLSPACING=0 CELLPADDING=4>

            <TR VALIGN=TOP>

                <Th ALIGN=TOP class='mathema'>
                    <b>CLASSI QUINTE</b>
                </Th>
            </tr>
            <tr><td><A HREF="Classi/5A RIM gruppo CIN 3.php" class = 'mathema'>5A RIM gruppo CIN 3</A><BR></td></tr>
<tr><td><A HREF="Classi/5A RIM gruppo SPA 3.php" class = 'mathema'>5A RIM gruppo SPA 3</A><BR></td></tr>
<tr><td><A HREF="Classi/5B RIM gruppo CIN 3.php" class = 'mathema'>5B RIM gruppo CIN 3</A><BR></td></tr>
<tr><td><A HREF="Classi/5B RIM gruppo SPA 3.php" class = 'mathema'>5B RIM gruppo SPA 3</A><BR></td></tr>
<tr><td><A HREF="Classi/5C RIM gruppo CIN 3.php" class = 'mathema'>5C RIM gruppo CIN 3</A><BR></td></tr>
<tr><td><A HREF="Classi/5C RIM gruppo TED 3.php" class = 'mathema'>5C RIM gruppo TED 3</A><BR></td></tr>
<tr><td><A HREF="Classi/5F TUR gruppo CIN 3.php" class = 'mathema'>5F TUR gruppo CIN 3</A><BR></td></tr>
<tr><td><A HREF="Classi/5F TUR gruppo FRA 3.php" class = 'mathema'>5F TUR gruppo FRA 3</A><BR></td></tr>
<tr><td><A HREF="Classi/5G TUR gruppo FRA 2.php" class = 'mathema'>5G TUR gruppo FRA 2</A><BR></td></tr>
<tr><td><A HREF="Classi/5G TUR gruppo TED 2.php" class = 'mathema'>5G TUR gruppo TED 2</A><BR></td></tr>
<tr><td><A HREF="Classi/5G TUR gruppo CIN 3.php" class = 'mathema'>5G TUR gruppo CIN 3</A><BR></td></tr>
<tr><td><A HREF="Classi/5G TUR gruppo FRA 3.php" class = 'mathema'>5G TUR gruppo FRA 3</A><BR></td></tr>
<tr><td><A HREF="Classi/5G TUR gruppo SPA 3.php" class = 'mathema'>5G TUR gruppo SPA 3</A><BR></td></tr>
        </TABLE>

</div>
</div>
        
        <div class='footer'>
        <?php include 'footer.html';?>

    </div>
</BODY>

</HTML>